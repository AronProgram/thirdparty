var searchData=
[
  ['ignore_5ftype0_1044',['ignore_type0',['../manip_8h.html#aecf53d5cc6a2962626f69dd69e45845f',1,'mysqlpp']]],
  ['isolationlevel_1045',['IsolationLevel',['../classmysqlpp_1_1Transaction.html#a91d16b4539a969fb632ee672999cdd1f',1,'mysqlpp::Transaction']]],
  ['isolationscope_1046',['IsolationScope',['../classmysqlpp_1_1Transaction.html#a933f0528d41cea97732d9e70e232612c',1,'mysqlpp::Transaction']]]
];
