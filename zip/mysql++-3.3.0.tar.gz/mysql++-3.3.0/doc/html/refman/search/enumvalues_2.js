var searchData=
[
  ['global_1058',['global',['../classmysqlpp_1_1Transaction.html#a933f0528d41cea97732d9e70e232612ca707b5ddb102ba887030eb7f15acfe80e',1,'mysqlpp::Transaction']]]
];
