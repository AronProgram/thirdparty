#include "soptwork.h"
#include "DataCollect.h"

CUser::CUser()
{
#ifdef __WIN_SYS
	m_Release_signal = CreateEvent(NULL, false, false, NULL);
	m_Init_signal = CreateEvent(NULL, false, false, NULL);
	m_Join_signal = CreateEvent(NULL, false, false, NULL);
	m_ReqAuthenticate_signal = CreateEvent(NULL, false, false, NULL);
	m_RegisterUserSystemInfo_signal = CreateEvent(NULL, false, false, NULL);
	m_SubmitUserSystemInfo_signal = CreateEvent(NULL, false, false, NULL);
	m_ReqUserLogin_signal = CreateEvent(NULL, false, false, NULL);
	m_ReqUserLogout_signal = CreateEvent(NULL, false, false, NULL);
	m_ReqUserPasswordUpdate_signal = CreateEvent(NULL, false, false, NULL);
	m_ReqTradingAccountPasswordUpdate_signal = CreateEvent(NULL, false, false, NULL);
	m_ReqOrderInsert_signal = CreateEvent(NULL, false, false, NULL);
	m_ReqParkedOrderInsert_signal = CreateEvent(NULL, false, false, NULL);
	m_ReqParkedOrderAction_signal = CreateEvent(NULL, false, false, NULL);
	m_ReqOrderAction_signal = CreateEvent(NULL, false, false, NULL);
	m_ReqQueryMaxOrderVolume_signal = CreateEvent(NULL, false, false, NULL);
	m_ReqSettlementInfoConfirm_signal = CreateEvent(NULL, false, false, NULL);
	m_ReqRemoveParkedOrder_signal = CreateEvent(NULL, false, false, NULL);
	m_ReqRemoveParkedOrderAction_signal = CreateEvent(NULL, false, false, NULL);
	m_ReqExecOrderInsert_signal = CreateEvent(NULL, false, false, NULL);
	m_ReqExecOrderAction_signal = CreateEvent(NULL, false, false, NULL);
	m_ReqForQuoteInsert_signal = CreateEvent(NULL, false, false, NULL);
	m_ReqQuoteInsert_signal = CreateEvent(NULL, false, false, NULL);
	m_ReqQuoteAction_signal = CreateEvent(NULL, false, false, NULL);
	m_ReqLockInsert_signal = CreateEvent(NULL, false, false, NULL);
	m_ReqBatchOrderAction_signal = CreateEvent(NULL, false, false, NULL);
	m_ReqCombActionInsert_signal = CreateEvent(NULL, false, false, NULL);
	m_ReqQryOrder_signal = CreateEvent(NULL, false, false, NULL);
	m_ReqQryTrade_signal = CreateEvent(NULL, false, false, NULL);
	m_ReqQryInvestorPosition_signal = CreateEvent(NULL, false, false, NULL);
	m_ReqQryTradingAccount_signal = CreateEvent(NULL, false, false, NULL);
	m_ReqQryInvestor_signal = CreateEvent(NULL, false, false, NULL);
	m_ReqQryTradingCode_signal = CreateEvent(NULL, false, false, NULL);
	m_ReqQryInstrumentMarginRate_signal = CreateEvent(NULL, false, false, NULL);
	m_ReqQryInstrumentCommissionRate_signal = CreateEvent(NULL, false, false, NULL);
	m_ReqQryExchange_signal = CreateEvent(NULL, false, false, NULL);
	m_ReqQryProduct_signal = CreateEvent(NULL, false, false, NULL);
	m_ReqQryInstrument_signal = CreateEvent(NULL, false, false, NULL);
	m_ReqQryDepthMarketData_signal = CreateEvent(NULL, false, false, NULL);
	m_ReqQrySettlementInfo_signal = CreateEvent(NULL, false, false, NULL);
	m_ReqQryTransferBank_signal = CreateEvent(NULL, false, false, NULL);
	m_ReqQryInvestorPositionDetail_signal = CreateEvent(NULL, false, false, NULL);
	m_ReqQryNotice_signal = CreateEvent(NULL, false, false, NULL);
	m_ReqQrySettlementInfoConfirm_signal = CreateEvent(NULL, false, false, NULL);
	m_ReqQryInvestorPositionCombineDetail_signal = CreateEvent(NULL, false, false, NULL);
	m_ReqQryCFMMCTradingAccountKey_signal = CreateEvent(NULL, false, false, NULL);
	m_ReqQryEWarrantOffset_signal = CreateEvent(NULL, false, false, NULL);
	m_ReqQryInvestorProductGroupMargin_signal = CreateEvent(NULL, false, false, NULL);
	m_ReqQryExchangeMarginRate_signal = CreateEvent(NULL, false, false, NULL);
	m_ReqQryExchangeMarginRateAdjust_signal = CreateEvent(NULL, false, false, NULL);
	m_ReqQryExchangeRate_signal = CreateEvent(NULL, false, false, NULL);
	m_ReqQrySecAgentACIDMap_signal = CreateEvent(NULL, false, false, NULL);
	m_ReqQryProductExchRate_signal = CreateEvent(NULL, false, false, NULL);
	m_ReqQryProductGroup_signal = CreateEvent(NULL, false, false, NULL);
	m_ReqQryMMInstrumentCommissionRate_signal = CreateEvent(NULL, false, false, NULL);
	m_ReqQryMMOptionInstrCommRate_signal = CreateEvent(NULL, false, false, NULL);
	m_ReqQryInstrumentOrderCommRate_signal = CreateEvent(NULL, false, false, NULL);
	m_ReqQryOptionInstrTradeCost_signal = CreateEvent(NULL, false, false, NULL);
	m_ReqQryOptionInstrCommRate_signal = CreateEvent(NULL, false, false, NULL);
	m_ReqQryExecOrder_signal = CreateEvent(NULL, false, false, NULL);
	m_ReqQryForQuote_signal = CreateEvent(NULL, false, false, NULL);
	m_ReqQryQuote_signal = CreateEvent(NULL, false, false, NULL);
	m_ReqQryLock_signal = CreateEvent(NULL, false, false, NULL);
	m_ReqQryLockPosition_signal = CreateEvent(NULL, false, false, NULL);
	m_ReqQryETFOptionInstrCommRate_signal = CreateEvent(NULL, false, false, NULL);
	m_ReqQryInvestorLevel_signal = CreateEvent(NULL, false, false, NULL);
	m_ReqQryExecFreeze_signal = CreateEvent(NULL, false, false, NULL);
	m_ReqQryCombInstrumentGuard_signal = CreateEvent(NULL, false, false, NULL);
	m_ReqQryCombAction_signal = CreateEvent(NULL, false, false, NULL);
	m_ReqQryTransferSerial_signal = CreateEvent(NULL, false, false, NULL);
	m_ReqQryAccountregister_signal = CreateEvent(NULL, false, false, NULL);
	m_ReqQryContractBank_signal = CreateEvent(NULL, false, false, NULL);
	m_ReqQryParkedOrder_signal = CreateEvent(NULL, false, false, NULL);
	m_ReqQryParkedOrderAction_signal = CreateEvent(NULL, false, false, NULL);
	m_ReqQryTradingNotice_signal = CreateEvent(NULL, false, false, NULL);
	m_ReqQryBrokerTradingParams_signal = CreateEvent(NULL, false, false, NULL);
	m_ReqQryBrokerTradingAlgos_signal = CreateEvent(NULL, false, false, NULL);
	m_ReqQueryCFMMCTradingAccountToken_signal = CreateEvent(NULL, false, false, NULL);
	m_ReqFromBankToFutureByFuture_signal = CreateEvent(NULL, false, false, NULL);
	m_ReqFromFutureToBankByFuture_signal = CreateEvent(NULL, false, false, NULL);
	m_ReqQueryBankAccountMoneyByFuture_signal = CreateEvent(NULL, false, false, NULL);
	m_ReqReserveOpenAccountTpdByFuture_signal = CreateEvent(NULL, false, false, NULL);
	m_ReqSecuritiesDepositInterestByFuture_signal = CreateEvent(NULL, false, false, NULL);
	m_ReqDayEndFileReadyByFuture_signal = CreateEvent(NULL, false, false, NULL);
	m_ReqExecCombineOrderInsert_signal = CreateEvent(NULL, false, false, NULL);
	m_ReqExecCombineOrderAction_signal = CreateEvent(NULL, false, false, NULL);
	m_ReqQryExecCombineOrder_signal = CreateEvent(NULL, false, false, NULL);
#elif defined(__UNIX_SYS)
	sem_init(&m_Release_signal, 0, 0);
	sem_init(&m_Init_signal, 0, 0);
	sem_init(&m_Join_signal, 0, 0);
	sem_init(&m_ReqAuthenticate_signal, 0, 0);
	sem_init(&m_RegisterUserSystemInfo_signal, 0, 0);
	sem_init(&m_SubmitUserSystemInfo_signal, 0, 0);
	sem_init(&m_ReqUserLogin_signal, 0, 0);
	sem_init(&m_ReqUserLogout_signal, 0, 0);
	sem_init(&m_ReqUserPasswordUpdate_signal, 0, 0);
	sem_init(&m_ReqTradingAccountPasswordUpdate_signal, 0, 0);
	sem_init(&m_ReqOrderInsert_signal, 0, 0);
	sem_init(&m_ReqParkedOrderInsert_signal, 0, 0);
	sem_init(&m_ReqParkedOrderAction_signal, 0, 0);
	sem_init(&m_ReqOrderAction_signal, 0, 0);
	sem_init(&m_ReqQueryMaxOrderVolume_signal, 0, 0);
	sem_init(&m_ReqSettlementInfoConfirsem_init(&m_signal, 0, 0);
	sem_init(&m_ReqRemoveParkedOrder_signal, 0, 0);
	sem_init(&m_ReqRemoveParkedOrderAction_signal, 0, 0);
	sem_init(&m_ReqExecOrderInsert_signal, 0, 0);
	sem_init(&m_ReqExecOrderAction_signal, 0, 0);
	sem_init(&m_ReqForQuoteInsert_signal, 0, 0);
	sem_init(&m_ReqQuoteInsert_signal, 0, 0);
	sem_init(&m_ReqQuoteAction_signal, 0, 0);
	sem_init(&m_ReqLockInsert_signal, 0, 0);
	sem_init(&m_ReqBatchOrderAction_signal, 0, 0);
	sem_init(&m_ReqCombActionInsert_signal, 0, 0);
	sem_init(&m_ReqQryOrder_signal, 0, 0);
	sem_init(&m_ReqQryTrade_signal, 0, 0);
	sem_init(&m_ReqQryInvestorPosition_signal, 0, 0);
	sem_init(&m_ReqQryTradingAccount_signal, 0, 0);
	sem_init(&m_ReqQryInvestor_signal, 0, 0);
	sem_init(&m_ReqQryTradingCode_signal, 0, 0);
	sem_init(&m_ReqQryInstrumentMarginRate_signal, 0, 0);
	sem_init(&m_ReqQryInstrumentCommissionRate_signal, 0, 0);
	sem_init(&m_ReqQryExchange_signal, 0, 0);
	sem_init(&m_ReqQryProduct_signal, 0, 0);
	sem_init(&m_ReqQryInstrument_signal, 0, 0);
	sem_init(&m_ReqQryDepthMarketData_signal, 0, 0);
	sem_init(&m_ReqQrySettlementInfo_signal, 0, 0);
	sem_init(&m_ReqQryTransferBank_signal, 0, 0);
	sem_init(&m_ReqQryInvestorPositionDetail_signal, 0, 0);
	sem_init(&m_ReqQryNotice_signal, 0, 0);
	sem_init(&m_ReqQrySettlementInfoConfirsem_init(&m_signal, 0, 0);
	sem_init(&m_ReqQryInvestorPositionCombineDetail_signal, 0, 0);
	sem_init(&m_ReqQryCFMMCTradingAccountKey_signal, 0, 0);
	sem_init(&m_ReqQryEWarrantOffset_signal, 0, 0);
	sem_init(&m_ReqQryInvestorProductGroupMargin_signal, 0, 0);
	sem_init(&m_ReqQryExchangeMarginRate_signal, 0, 0);
	sem_init(&m_ReqQryExchangeMarginRateAdjust_signal, 0, 0);
	sem_init(&m_ReqQryExchangeRate_signal, 0, 0);
	sem_init(&m_ReqQrySecAgentACIDMap_signal, 0, 0);
	sem_init(&m_ReqQryProductExchRate_signal, 0, 0);
	sem_init(&m_ReqQryProductGroup_signal, 0, 0);
	sem_init(&m_ReqQryMMInstrumentCommissionRate_signal, 0, 0);
	sem_init(&m_ReqQryMMOptionInstrCommRate_signal, 0, 0);
	sem_init(&m_ReqQryInstrumentOrderCommRate_signal, 0, 0);
	sem_init(&m_ReqQryOptionInstrTradeCost_signal, 0, 0);
	sem_init(&m_ReqQryOptionInstrCommRate_signal, 0, 0);
	sem_init(&m_ReqQryExecOrder_signal, 0, 0);
	sem_init(&m_ReqQryForQuote_signal, 0, 0);
	sem_init(&m_ReqQryQuote_signal, 0, 0);
	sem_init(&m_ReqQryLock_signal, 0, 0);
	sem_init(&m_ReqQryLockPosition_signal, 0, 0);
	sem_init(&m_ReqQryETFOptionInstrCommRate_signal, 0, 0);
	sem_init(&m_ReqQryInvestorLevel_signal, 0, 0);
	sem_init(&m_ReqQryExecFreeze_signal, 0, 0);
	sem_init(&m_ReqQryCombInstrumentGuard_signal, 0, 0);
	sem_init(&m_ReqQryCombAction_signal, 0, 0);
	sem_init(&m_ReqQryTransferSerial_signal, 0, 0);
	sem_init(&m_ReqQryAccountregister_signal, 0, 0);
	sem_init(&m_ReqQryContractBank_signal, 0, 0);
	sem_init(&m_ReqQryParkedOrder_signal, 0, 0);
	sem_init(&m_ReqQryParkedOrderAction_signal, 0, 0);
	sem_init(&m_ReqQryTradingNotice_signal, 0, 0);
	sem_init(&m_ReqQryBrokerTradingParams_signal, 0, 0);
	sem_init(&m_ReqQryBrokerTradingAlgos_signal, 0, 0);
	sem_init(&m_ReqQueryCFMMCTradingAccountToken_signal, 0, 0);
	sem_init(&m_ReqFromBankToFutureByFuture_signal, 0, 0);
	sem_init(&m_ReqFromFutureToBankByFuture_signal, 0, 0);
	sem_init(&m_ReqQueryBankAccountMoneyByFuture_signal, 0, 0);
	sem_init(&m_ReqReserveOpenAccountTpdByFuture_signal, 0, 0);
	sem_init(&m_ReqSecuritiesDepositInterestByFuture_signal, 0, 0);
	sem_init(&m_ReqDayEndFileReadyByFuture_signal, 0, 0);
	sem_init(&m_ReqExecCombineOrderInsert_signal, 0, 0);
	sem_init(&m_ReqExecCombineOrderAction_signal, 0, 0);
	sem_init(&m_ReqQryExecCombineOrder_signal, 0, 0);
#endif // __WIN_SYS

	RequestID = 0;
	m_FrontAddr = getConfig("config", "FrontAddr");
	strncpy(m_BrokerID, getConfig("config", "BrokerID").c_str(), sizeof(m_BrokerID));
	strncpy(m_AppID, getConfig("config", "AppID").c_str(), sizeof(m_AppID));
	strncpy(m_AuthCode, getConfig("config", "AuthCode").c_str(), sizeof(m_AuthCode));
	strncpy(m_UserID, getConfig("config", "UserID").c_str(), sizeof(m_UserID));
	strncpy(m_InvestorID, getConfig("config", "InvestorID").c_str(), sizeof(m_InvestorID));
	strncpy(m_InstrumentID, getConfig("config", "InstrumentID").c_str(), sizeof(m_InstrumentID));
	m_pTrader = new CTraderApi;
	m_loginflag = false;
}

CUser::~CUser()
{
	delete m_pTrader;
}

void CUser::Release()
{
	m_pTrader->Release();
}

void CUser::Init()
{
	m_pTrader->CreateFtdcTraderApi("./flow/");
	m_pTrader->RegisterSpi(this);	
	m_pTrader->SubscribePublicTopic(THOST_TERT_QUICK);
	m_pTrader->SubscribePrivateTopic(THOST_TERT_QUICK); //����˽��������ģʽ	
	m_pTrader->RegisterFront(const_cast<char *>(m_FrontAddr.c_str()));
	m_pTrader->Init();

#ifdef __WIN_SYS
	WaitForSingleObject(m_Init_signal, INFINITE);
#elif defined(__UNIX_SYS)
	sem_wait(&m_Init_signal);
#endif // __WIN_SYS

}

void CUser::Join()
{
	m_pTrader->Join();
}

void CUser::ReqAuthenticate()
{
	CThostFtdcReqAuthenticateField pReqAuthenticateField;
	memset(&pReqAuthenticateField, 0, sizeof(CThostFtdcReqAuthenticateField));
	strcpy(pReqAuthenticateField.BrokerID, m_BrokerID);
	strcpy(pReqAuthenticateField.AppID, m_AppID);
	strcpy(pReqAuthenticateField.AuthCode, m_AuthCode);
	int a = m_pTrader->ReqAuthenticate(&pReqAuthenticateField, RequestID++);
	LOG((a == 0) ? "�ն���֤����......���ͳɹ�[%d]\n" : "�ն���֤����......����ʧ�ܣ��������=[%d]\n", a);

#ifdef __WIN_SYS
	WaitForSingleObject(m_ReqAuthenticate_signal, INFINITE);
#elif defined(__UNIX_SYS)
	sem_wait(&m_ReqAuthenticate_signal);
#endif // __WIN_SYS
}

void CUser::RegisterUserSystemInfo()
{
	CThostFtdcUserSystemInfoField pUserSystemInfo;
	memset(&pUserSystemInfo, 0, sizeof(CThostFtdcUserSystemInfoField));
	char pSystemInfo[344];
	int strlen = 0;
	CTP_GetSystemInfo(pSystemInfo, strlen);
	memcpy(pUserSystemInfo.ClientSystemInfo, pSystemInfo, strlen);
	pUserSystemInfo.ClientSystemInfoLen = strlen;
	strcpy(pUserSystemInfo.BrokerID, m_BrokerID);
	strcpy(pUserSystemInfo.UserID, m_UserID);
	strcpy(pUserSystemInfo.ClientPublicIP, "127.0.0.1");
	pUserSystemInfo.ClientIPPort = 4001;
	strcpy(pUserSystemInfo.ClientAppID, "test_client_v1.0");
	int a = m_pTrader->RegisterUserSystemInfo(&pUserSystemInfo);
	LOG((a == 0) ? "ע���û��ն���Ϣ......���ͳɹ�[%d]\n" : "ע���û��ն���Ϣ......����ʧ�ܣ��������=[%d]\n", a);
}

void CUser::SubmitUserSystemInfo()
{
	CThostFtdcUserSystemInfoField pUserSystemInfo;
	memset(&pUserSystemInfo, 0, sizeof(CThostFtdcUserSystemInfoField));
	char pSystemInfo[344];
	int strlen = 0;
	CTP_GetSystemInfo(pSystemInfo, strlen);
	memcpy(pUserSystemInfo.ClientSystemInfo, pSystemInfo, strlen);
	strcpy(pUserSystemInfo.BrokerID, m_BrokerID);
	strcpy(pUserSystemInfo.UserID, m_UserID);
	pUserSystemInfo.ClientSystemInfoLen = strlen;
	strcpy(pUserSystemInfo.ClientPublicIP, "127.0.0.1");
	pUserSystemInfo.ClientIPPort = 4001;
	strcpy(pUserSystemInfo.ClientAppID, "test_client_v1.0");
	int a = m_pTrader->SubmitUserSystemInfo(&pUserSystemInfo);
	LOG((a == 0) ? "ע���û��ն���Ϣ......���ͳɹ�[%d]\n" : "ע���û��ն���Ϣ......����ʧ�ܣ��������=[%d]\n", a);
}

void CUser::ReqUserLogin()
{
	CThostFtdcReqUserLoginField pReqUserLoginField;
	memset(&pReqUserLoginField, 0, sizeof(CThostFtdcReqUserLoginField));
	strcpy(pReqUserLoginField.BrokerID, m_BrokerID);
	strcpy(pReqUserLoginField.UserID, m_UserID);
	strncpy(m_Password, getConfig("config", "Password").c_str(), sizeof(m_Password));
	strcpy(pReqUserLoginField.Password, m_Password);
	int a = m_pTrader->ReqUserLogin(&pReqUserLoginField, RequestID++);
	LOG((a == 0) ? "�û���¼����......���ͳɹ�[%d]\n" : "�û���¼����......����ʧ�ܣ��������=[%d]\n", a);

#ifdef __WIN_SYS
	WaitForSingleObject(m_ReqUserLogin_signal, INFINITE);
#elif defined(__UNIX_SYS)
	sem_wait(&m_ReqUserLogin_signal);
#endif // __WIN_SYS
}

void CUser::ReqUserLogout()
{
	CThostFtdcUserLogoutField pUserLogout;
	memset(&pUserLogout, 0, sizeof(CThostFtdcUserLogoutField));
	strcpy(pUserLogout.BrokerID, m_BrokerID);
	strcpy(pUserLogout.UserID, m_UserID);
	int a = m_pTrader->ReqUserLogout(&pUserLogout, RequestID++);
	LOG((a == 0) ? "�û��ǳ�����......���ͳɹ�[%d]\n" : "�û��ǳ�����......����ʧ�ܣ��������=[%d]\n", a);

#ifdef __WIN_SYS
	WaitForSingleObject(m_ReqUserLogout_signal, INFINITE);
#elif defined(__UNIX_SYS)
	sem_wait(&m_ReqUserLogout_signal);
#endif // __WIN_SYS
}

void CUser::ReqUserPasswordUpdate()
{
	CThostFtdcUserPasswordUpdateField pUserPasswordUpdate;
	memset(&pUserPasswordUpdate, 0, sizeof(CThostFtdcUserPasswordUpdateField));
	strcpy(pUserPasswordUpdate.BrokerID, m_BrokerID);
	strcpy(pUserPasswordUpdate.UserID, m_UserID);
	string __oldpassword;
	std::cout << "�����������: " << endl;
	std::cin >> __oldpassword;
	strcpy(pUserPasswordUpdate.OldPassword, __oldpassword.c_str());
	string __newpassword;
	std::cout << "������������: " << endl;
	std::cin >> __newpassword;
	strcpy(pUserPasswordUpdate.NewPassword, __newpassword.c_str());
	int a = m_pTrader->ReqUserPasswordUpdate(&pUserPasswordUpdate, RequestID++);
	LOG((a == 0) ? "�û��޸ĵ�¼��������......���ͳɹ�[%d]\n" : "�û��޸ĵ�¼��������......����ʧ�ܣ��������=[%d]\n", a);

#ifdef __WIN_SYS
	WaitForSingleObject(m_ReqUserPasswordUpdate_signal, INFINITE);
#elif defined(__UNIX_SYS)
	sem_wait(&m_ReqUserPasswordUpdate_signal);
#endif // __WIN_SYS

}

void CUser::ReqTradingAccountPasswordUpdate()
{
	CThostFtdcTradingAccountPasswordUpdateField pTradingAccountPasswordUpdate;
	memset(&pTradingAccountPasswordUpdate, 0, sizeof(CThostFtdcTradingAccountPasswordUpdateField));
	strcpy(pTradingAccountPasswordUpdate.BrokerID, m_BrokerID);
	strcpy(pTradingAccountPasswordUpdate.AccountID, m_InvestorID);
	string __oldpassword;
	std::cout << "�����������: " << endl;
	std::cin >> __oldpassword;
	strcpy(pTradingAccountPasswordUpdate.OldPassword, __oldpassword.c_str());
	string __newpassword;
	std::cout << "������������: " << endl;
	std::cin >> __newpassword;
	strcpy(pTradingAccountPasswordUpdate.NewPassword, __newpassword.c_str());
	strcpy(pTradingAccountPasswordUpdate.CurrencyID, "CNY");
	int a = m_pTrader->ReqTradingAccountPasswordUpdate(&pTradingAccountPasswordUpdate, RequestID++);
	LOG((a == 0) ? "�û��޸��ʽ���������......���ͳɹ�[%d]\n" : "�û��޸��ʽ���������......����ʧ�ܣ��������=[%d]\n", a);

//#ifdef __WIN_SYS
//	WaitForSingleObject(m_ReqTradingAccountPasswordUpdate_signal, INFINITE);
//#elif defined(__UNIX_SYS)
//	sem_wait(&m_ReqTradingAccountPasswordUpdate_signal);
//#endif // __WIN_SYS
}

void CUser::ReqOrderInsert()
{
	CThostFtdcInputOrderField pInputOrder;
	memset(&pInputOrder, 0, sizeof(CThostFtdcInputOrderField));
	strcpy(pInputOrder.BrokerID, m_BrokerID);
	strcpy(pInputOrder.InvestorID, m_InvestorID);
	strncpy(pInputOrder.InstrumentID, getConfig("config", "InstrumentID").c_str(), sizeof(pInputOrder.InstrumentID));
	strcpy(pInputOrder.UserID, m_UserID);
	string _order_mode;
	std::cout << std::endl;
	std::cout << "�����뱨������: " << std::endl;
	std::cout << "1.��ͨ�޼�" << std::endl;
	std::cout << "2.ȫ�ʱ�޼�(�޼�FOK)" << std::endl;
	std::cout << "3.�м�ʣ��ת�޼�" << std::endl;
	std::cout << "4.�м�ʣ�೷��(FAK)" << std::endl;
	std::cout << "5.ȫ�ʱ�м�(�м�FOK)" << std::endl;
	std::cout << "6.�����嵵��ʱ�ɽ�ʣ�೷��" << std::endl;
	std::cout << "7.�����嵵��ʱ�ɽ�ʣ��ת�޼�" << std::endl;
	std::cout << "8.�������ż��м�" << std::endl;
	std::cin >> _order_mode;

	switch (atoi(_order_mode.c_str()))
	{
	case 1:
	{
		pInputOrder.OrderPriceType = THOST_FTDC_OPT_LimitPrice;
		pInputOrder.TimeCondition = THOST_FTDC_TC_GFD;
		pInputOrder.VolumeCondition = THOST_FTDC_VC_AV;
		string __limitprice;
		std::cout << "������۸�: " << endl;
		std::cin >> __limitprice;
		pInputOrder.LimitPrice = atof(__limitprice.c_str());
		break;
	}
	case 2:
	{
		pInputOrder.OrderPriceType = THOST_FTDC_OPT_LimitPrice;
		pInputOrder.TimeCondition = THOST_FTDC_TC_IOC;
		pInputOrder.VolumeCondition = THOST_FTDC_VC_CV;
		string __limitprice;
		std::cout << "������۸�: " << endl;
		std::cin >> __limitprice;
		pInputOrder.LimitPrice = atof(__limitprice.c_str());
		break;
	}
	case 3:
	{
		pInputOrder.OrderPriceType = THOST_FTDC_OPT_BestPrice;
		pInputOrder.TimeCondition = THOST_FTDC_TC_GFD;
		pInputOrder.VolumeCondition = THOST_FTDC_VC_AV;
		pInputOrder.LimitPrice = 0;
		break;
	}
	case 4:
	{
		pInputOrder.OrderPriceType = THOST_FTDC_OPT_BestPrice;
		pInputOrder.TimeCondition = THOST_FTDC_TC_IOC;
		pInputOrder.VolumeCondition = THOST_FTDC_VC_AV;
		pInputOrder.LimitPrice = 0;
		break;
	}
	case 5:
	{
		pInputOrder.OrderPriceType = THOST_FTDC_OPT_BestPrice;
		pInputOrder.TimeCondition = THOST_FTDC_TC_IOC;
		pInputOrder.VolumeCondition = THOST_FTDC_VC_CV;
		pInputOrder.LimitPrice = 0;
		break;
	}
	case 6:
	{
		pInputOrder.OrderPriceType = THOST_FTDC_OPT_FiveLevelPrice;
		pInputOrder.TimeCondition = THOST_FTDC_TC_IOC;
		pInputOrder.VolumeCondition = THOST_FTDC_VC_AV;
		pInputOrder.LimitPrice = 0;
		break;
	}
	case 7:
	{
		pInputOrder.OrderPriceType = THOST_FTDC_OPT_FiveLevelPrice;
		pInputOrder.TimeCondition = THOST_FTDC_TC_GFD;
		pInputOrder.VolumeCondition = THOST_FTDC_VC_AV;
		pInputOrder.LimitPrice = 0;
		break;
	}
	case 8:
	{
		pInputOrder.OrderPriceType = THOST_FTDC_OPT_BestPriceThisSide;
		pInputOrder.TimeCondition = THOST_FTDC_TC_GFD;
		pInputOrder.VolumeCondition = THOST_FTDC_VC_AV;
		pInputOrder.LimitPrice = 0;
		break;
	}
	default:
	{
		std::cout << "ReqOrderInsert�޴�ѡ�� ������" << endl;
		return;
	}
	}

	pInputOrder.VolumeTotalOriginal = 1;	
	pInputOrder.ContingentCondition = THOST_FTDC_CC_Immediately;
	pInputOrder.ForceCloseReason = THOST_FTDC_FCC_NotForceClose;
	pInputOrder.Direction = THOST_FTDC_D_Buy;
	pInputOrder.CombOffsetFlag[0] = THOST_FTDC_OF_Open;
	pInputOrder.CombHedgeFlag[0] = THOST_FTDC_HF_Speculation;
	strcpy(pInputOrder.AccountID, m_InvestorID);
	strcpy(pInputOrder.CurrencyID, "CNY");
	int a = m_pTrader->ReqOrderInsert(&pInputOrder, RequestID++);
	LOG((a == 0) ? "�û���������......���ͳɹ�[%d]\n" : "�û���������......����ʧ�ܣ��������=[%d]\n", a);

}


//Ԥ��-���⣬�ݲ�֪�Ƿ�֧��
void CUser::ReqParkedOrderInsert()
{
	CThostFtdcParkedOrderField pParkedOrder;
	memset(&pParkedOrder, 0, sizeof(CThostFtdcParkedOrderField));
	strcpy(pParkedOrder.BrokerID, m_BrokerID);
	strcpy(pParkedOrder.InvestorID, m_InvestorID);
	strncpy(pParkedOrder.InstrumentID, getConfig("config", "InstrumentID").c_str(), sizeof(pParkedOrder.InstrumentID));
	strcpy(pParkedOrder.UserID, m_UserID);
	pParkedOrder.OrderPriceType = THOST_FTDC_OPT_LimitPrice;
	pParkedOrder.Direction = THOST_FTDC_D_Buy;
	pParkedOrder.CombOffsetFlag[0] = THOST_FTDC_OF_Open;
	pParkedOrder.CombHedgeFlag[0] = THOST_FTDC_HF_Speculation;
	string __limitprice;
	std::cout << "������۸�: " << endl;
	std::cin >> __limitprice;
	pParkedOrder.LimitPrice = atof(__limitprice.c_str());
	pParkedOrder.VolumeTotalOriginal = 1;
	pParkedOrder.TimeCondition = THOST_FTDC_TC_GFD;
	pParkedOrder.VolumeCondition = THOST_FTDC_VC_AV;
	pParkedOrder.ContingentCondition = THOST_FTDC_CC_Immediately;
	pParkedOrder.ForceCloseReason = THOST_FTDC_FCC_NotForceClose;
	strncpy(m_ExchangeID, getConfig("config", "ExchangeID").c_str(), sizeof(m_ExchangeID));
	strcpy(pParkedOrder.ExchangeID, m_ExchangeID);
	strcpy(pParkedOrder.AccountID, m_InvestorID);
	strcpy(pParkedOrder.CurrencyID, "CNY");
	int a = m_pTrader->ReqParkedOrderInsert(&pParkedOrder, RequestID++);
	LOG((a == 0) ? "�û�Ԥ������......���ͳɹ�[%d]\n" : "�û�Ԥ������......����ʧ�ܣ��������=[%d]\n", a);

}

void CUser::ReqParkedOrderAction()
{

}

void CUser::ReqOrderAction()
{
	CThostFtdcInputOrderActionField pInputOrderAction;
	memset(&pInputOrderAction, 0, sizeof(CThostFtdcInputOrderActionField));
	strcpy(pInputOrderAction.BrokerID, m_BrokerID);
	strcpy(pInputOrderAction.InvestorID, m_InvestorID);
	pInputOrderAction.OrderActionRef = 0;
	//strcpy(pInputOrderAction.OrderRef, "1");
	//pInputOrderAction.FrontID = 1;
	//pInputOrderAction.SessionID = 1;
	string __exchangeid;
	string __chosen;
	std::cout << "��ѡ������: 1.SSE  ����.SZSE" << endl;
	std::cin >> __chosen;
	(__chosen == "1") ? __exchangeid = "SSE" : __exchangeid = "SZSE";
	strcpy(pInputOrderAction.ExchangeID, __exchangeid.c_str());
	string __ordersysid;
	std::cout << "�����뱨�����(OrderSysID):" << endl;
	std::cin >> __ordersysid;
	strcpy(pInputOrderAction.OrderSysID, __ordersysid.c_str());
	pInputOrderAction.ActionFlag = THOST_FTDC_AF_Delete;

	int a = m_pTrader->ReqOrderAction(&pInputOrderAction, RequestID++);
	LOG((a == 0) ? "�û���������......���ͳɹ�[%d]\n" : "�û���������......����ʧ�ܣ��������=[%d]\n", a);

}

void CUser::ReqQueryMaxOrderVolume()
{
	CThostFtdcQueryMaxOrderVolumeField pQueryMaxOrderVolume;
	memset(&pQueryMaxOrderVolume, 0, sizeof(CThostFtdcQueryMaxOrderVolumeField));
	strcpy(pQueryMaxOrderVolume.BrokerID, m_BrokerID);
	strcpy(pQueryMaxOrderVolume.InvestorID, m_InvestorID);
	strncpy(pQueryMaxOrderVolume.InstrumentID, getConfig("config", "InstrumentID").c_str(), sizeof(pQueryMaxOrderVolume.InstrumentID));
	pQueryMaxOrderVolume.Direction = '0';
	pQueryMaxOrderVolume.OffsetFlag = THOST_FTDC_OF_Open;
	pQueryMaxOrderVolume.HedgeFlag = THOST_FTDC_HF_Speculation;
	strcpy(pQueryMaxOrderVolume.ExchangeID, "SSE");

	int a = m_pTrader->ReqQueryMaxOrderVolume(&pQueryMaxOrderVolume, RequestID++);
	LOG((a == 0) ? "�û���ѯ��󱨵���������......���ͳɹ�[%d]\n" : "�û���ѯ��󱨵���������......����ʧ�ܣ��������=[%d]\n", a);

//#ifdef __WIN_SYS
//	WaitForSingleObject(m_ReqQueryMaxOrderVolume_signal, INFINITE);
//#elif defined(__UNIX_SYS)
//	sem_wait(&m_ReqQueryMaxOrderVolume_signal);
//#endif // __WIN_SYS
}

void CUser::ReqSettlementInfoConfirm()
{
	CThostFtdcSettlementInfoConfirmField pSettlementInfoConfirm;
	memset(&pSettlementInfoConfirm, 0, sizeof(CThostFtdcSettlementInfoConfirmField));
	strcpy(pSettlementInfoConfirm.BrokerID, m_BrokerID);
	strcpy(pSettlementInfoConfirm.InvestorID, m_InvestorID);

	int a = m_pTrader->ReqSettlementInfoConfirm(&pSettlementInfoConfirm, RequestID++);
	LOG((a == 0) ? "�û����㵥ȷ������......���ͳɹ�[%d]\n" : "�û����㵥ȷ������......����ʧ�ܣ��������=[%d]\n", a);

//#ifdef __WIN_SYS
//	WaitForSingleObject(m_ReqSettlementInfoConfirm_signal, INFINITE);
//#elif defined(__UNIX_SYS)
//	sem_wait(&m_ReqSettlementInfoConfirm_signal);
//#endif // __WIN_SYS

}

void CUser::ReqRemoveParkedOrder()
{
}

void CUser::ReqRemoveParkedOrderAction()
{
}

void CUser::ReqExecOrderInsert()
{
	CThostFtdcInputExecOrderField pInputExecOrder;
	memset(&pInputExecOrder, 0, sizeof(CThostFtdcInputExecOrderField));
	strcpy(pInputExecOrder.BrokerID, m_BrokerID);
	strcpy(pInputExecOrder.InvestorID, m_InvestorID);
	strcpy(pInputExecOrder.InstrumentID, m_InstrumentID);
	strcpy(pInputExecOrder.UserID, m_UserID);
	pInputExecOrder.Volume = 10;
	//pInputExecOrder.PosiDirection = THOST_FTDC_PD_Long;
	pInputExecOrder.ActionType = THOST_FTDC_ACTP_Exec;
	pInputExecOrder.CloseFlag = THOST_FTDC_EOCF_NotToClose;
	string __exchangeid;
	string __chosen;
	std::cout << "��ѡ������: 1.SSE  ����.SZSE" << endl;
	std::cin >> __chosen;
	(__chosen == "1") ? __exchangeid = "SSE" : __exchangeid = "SZSE";
	strcpy(pInputExecOrder.ExchangeID, __exchangeid.c_str());

	int a = m_pTrader->ReqExecOrderInsert(&pInputExecOrder, RequestID++);
	LOG((a == 0) ? "ִ������¼������......���ͳɹ�[%d]\n" : "ִ������¼������......����ʧ�ܣ��������=[%d]\n", a);

//#ifdef __WIN_SYS
//	WaitForSingleObject(m_ReqExecOrderInsert_signal, INFINITE);
//#elif defined(__UNIX_SYS)
//	sem_wait(&m_ReqExecOrderInsert_signal);
//#endif // __WIN_SYS

}

void CUser::ReqExecOrderAction()
{
	CThostFtdcInputExecOrderActionField pInputExecOrderAction;
	memset(&pInputExecOrderAction, 0, sizeof(CThostFtdcInputExecOrderActionField));
	strcpy(pInputExecOrderAction.BrokerID, m_BrokerID);
	strcpy(pInputExecOrderAction.InvestorID, m_InvestorID);
	//strcpy(pInputExecOrderAction.ExecOrderRef, "xxx");
	//pInputExecOrderAction.FrontID = 1;
	//pInputExecOrderAction.SessionID = 2222;

	string __exchangeid;
	string __chosen;
	std::cout << "��ѡ������: 1.SSE  ����.SZSE" << endl;
	std::cin >> __chosen;
	(__chosen == "1") ? __exchangeid = "SSE" : __exchangeid = "SZSE";
	strcpy(pInputExecOrderAction.ExchangeID, __exchangeid.c_str());
	string __execordersysid;
	std::cout << "�����뱨�����:" << endl;
	std::cin >> __execordersysid;
	strcpy(pInputExecOrderAction.ExecOrderSysID, __execordersysid.c_str());
	pInputExecOrderAction.ActionFlag = THOST_FTDC_AF_Delete;
	strcpy(pInputExecOrderAction.UserID, m_UserID);
	strcpy(pInputExecOrderAction.InstrumentID, m_InstrumentID);
 
	int a = m_pTrader->ReqExecOrderAction(&pInputExecOrderAction, RequestID++);
	LOG((a == 0) ? "ִ�������������......���ͳɹ�[%d]\n" : "ִ�������������......����ʧ�ܣ��������=[%d]\n", a);

//#ifdef __WIN_SYS
//	WaitForSingleObject(m_ReqExecOrderAction_signal, INFINITE);
//#elif defined(__UNIX_SYS)
//	sem_wait(&m_ReqExecOrderAction_signal);
//#endif // __WIN_SYS

}

void CUser::ReqForQuoteInsert()
{
	CThostFtdcInputForQuoteField pInputForQuote;
	memset(&pInputForQuote, 0, sizeof(CThostFtdcInputForQuoteField));
	strcpy(pInputForQuote.BrokerID, m_BrokerID);
	strcpy(pInputForQuote.InvestorID, m_InvestorID);
	strcpy(pInputForQuote.InstrumentID, m_InstrumentID);
	strcpy(pInputForQuote.UserID, m_UserID);
	string __exchangeid;
	string __chosen;
	std::cout << "��ѡ������: 1.SSE  ����.SZSE" << endl;
	std::cin >> __chosen;
	(__chosen == "1") ? __exchangeid = "SSE" : __exchangeid = "SZSE";
	strcpy(pInputForQuote.ExchangeID, __exchangeid.c_str());
	
	int a = m_pTrader->ReqForQuoteInsert(&pInputForQuote, RequestID++);
	LOG((a == 0) ? "ѯ��¼������......���ͳɹ�[%d]\n" : "ѯ��¼������......����ʧ�ܣ��������=[%d]\n", a);

//#ifdef __WIN_SYS
//	WaitForSingleObject(m_ReqForQuoteInsert_signal, INFINITE);
//#elif defined(__UNIX_SYS)
//	sem_wait(&m_ReqForQuoteInsert_signal);
//#endif // __WIN_SYS
}

void CUser::ReqQuoteInsert()
{
	CThostFtdcInputQuoteField pInputQuote;
	memset(&pInputQuote, 0, sizeof(CThostFtdcInputQuoteField));
	strcpy(pInputQuote.BrokerID, m_BrokerID);
	strcpy(pInputQuote.InvestorID, m_InvestorID);
	strcpy(pInputQuote.InstrumentID, m_InstrumentID);
	strcpy(pInputQuote.UserID, m_UserID);
	string __askprice;
	string __bidprice;
	cout <<  "��������۸�: ";
	cin >> __bidprice;

	cout << "���������۸�: ";
	cin >> __askprice;

	//std::cin.ignore();
	pInputQuote.AskPrice = atof(__askprice.c_str());
	pInputQuote.BidPrice = atof(__bidprice.c_str());
	pInputQuote.AskVolume = 1;
	pInputQuote.BidVolume = 1;
	pInputQuote.AskOffsetFlag = THOST_FTDC_OF_Open;
	pInputQuote.BidOffsetFlag = THOST_FTDC_OF_Open;
	pInputQuote.AskHedgeFlag = THOST_FTDC_HF_Speculation;
	pInputQuote.BidHedgeFlag = THOST_FTDC_HF_Speculation;

	int a = m_pTrader->ReqQuoteInsert(&pInputQuote, RequestID++);
	LOG((a == 0) ? "����¼������......���ͳɹ�[%d]\n" : "����¼������......����ʧ�ܣ��������=[%d]\n", a);

}

void CUser::ReqQuoteAction()
{
	CThostFtdcInputQuoteActionField pInputQuoteAction;
	memset(&pInputQuoteAction, 0, sizeof(CThostFtdcInputQuoteActionField));
	strcpy(pInputQuoteAction.BrokerID, m_BrokerID);
	strcpy(pInputQuoteAction.InvestorID, m_InvestorID);
	//strcpy(pInputQuoteAction.QuoteRef, "xxxx");
	//pInputQuoteAction.FrontID = 1;
	//pInputQuoteAction.SessionID = 222;

	string __exchangeid;
	string __chosen;
	std::cout << "��ѡ������: 1.SSE  ����.SZSE" << endl;
	std::cin >> __chosen;
	(__chosen == "1") ? __exchangeid = "SSE" : __exchangeid = "SZSE";
	strcpy(pInputQuoteAction.ExchangeID, __exchangeid.c_str());

	string __quotesysid;
	std::cout << "�����뱨�����:" << endl;
	std::cin >> __quotesysid;
	strcpy(pInputQuoteAction.QuoteSysID, __quotesysid.c_str());

	pInputQuoteAction.ActionFlag = THOST_FTDC_AF_Delete;
	strcpy(pInputQuoteAction.UserID, m_UserID);
	strcpy(pInputQuoteAction.InstrumentID, m_InstrumentID);

	int a = m_pTrader->ReqQuoteAction(&pInputQuoteAction, RequestID++);
	LOG((a == 0) ? "���۲�������......���ͳɹ�[%d]\n" : "���۲�������......����ʧ�ܣ��������=[%d]\n", a);

////#ifdef __WIN_SYS
////	WaitForSingleObject(m_ReqQuoteAction_signal, INFINITE);
////#elif defined(__UNIX_SYS)
////	sem_wait(&m_ReqQuoteAction_signal);
////#endif // __WIN_SYS

}

void CUser::ReqLockInsert()
{
	CThostFtdcInputLockField pInputLock;
	memset(&pInputLock, 0, sizeof(CThostFtdcInputLockField));
	strcpy(pInputLock.BrokerID, m_BrokerID);
	strcpy(pInputLock.InvestorID, m_InvestorID);
	strcpy(pInputLock.ExchangeID, "SSE");//�����ֶ�
	string __stockinstrumentid;
	std::cout << "�������Լ���: " << endl;
	std::cin >> __stockinstrumentid;
	strcpy(pInputLock.InstrumentID, __stockinstrumentid.c_str());
	pInputLock.Volume = 1;

	char _locktype;
	string __chosen;
	std::cout << "��ѡ�����: 1.����  2.����" << endl;
	std::cin >> __chosen;
	(__chosen == "1") ? _locktype = THOST_FTDC_LCKT_Lock : _locktype = THOST_FTDC_LCKT_Unlock;

	pInputLock.LockType = _locktype;

	int a = m_pTrader->ReqLockInsert(&pInputLock, RequestID++);
	LOG((a == 0) ? "��������......���ͳɹ�[%d]\n" : "��������......����ʧ�ܣ��������=[%d]\n", a);

//#ifdef __WIN_SYS
//	WaitForSingleObject(m_ReqLockInsert_signal, INFINITE);
//#elif defined(__UNIX_SYS)
//	sem_wait(&m_ReqLockInsert_signal);
//#endif // __WIN_SYS
}

void CUser::ReqBatchOrderAction()
{
	CThostFtdcInputBatchOrderActionField pInputBatchOrderAction;
	memset(&pInputBatchOrderAction, 0, sizeof(CThostFtdcInputBatchOrderActionField));
	strcpy(pInputBatchOrderAction.BrokerID, m_BrokerID);
	strcpy(pInputBatchOrderAction.InvestorID, m_InvestorID);

	int a = m_pTrader->ReqBatchOrderAction(&pInputBatchOrderAction, RequestID++);
	LOG((a == 0) ? "����������������......���ͳɹ�[%d]\n" : "����������������......����ʧ�ܣ��������=[%d]\n", a);

//#ifdef __WIN_SYS
//	WaitForSingleObject(m_ReqBatchOrderAction_signal, INFINITE);
//#elif defined(__UNIX_SYS)
//	sem_wait(&m_ReqBatchOrderAction_signal);
//#endif // __WIN_SYS
}

void CUser::ReqCombActionInsert()
{
	LOG("\n====ReqCombActionInsert====,�������/�����..\n");
	CThostFtdcInputCombActionField pInputCombAction;
	memset(&pInputCombAction, 0, sizeof(CThostFtdcInputCombActionField));
	strcpy(pInputCombAction.BrokerID, m_BrokerID);
	strcpy(pInputCombAction.InvestorID, m_InvestorID);
	strcpy(pInputCombAction.InstrumentID, m_InstrumentID);

	pInputCombAction.HedgeFlag = THOST_FTDC_HF_Speculation;

	string __exchangeid;
	string __chosen;
	std::cout << "��ѡ������: 1.SSE  ����.SZSE" << std::endl;
	std::cin >> __chosen;
	(__chosen == "1") ? __exchangeid = "SSE" : __exchangeid = "SZSE";
	strcpy(pInputCombAction.ExchangeID, __exchangeid.c_str());

	pInputCombAction.Direction = THOST_FTDC_D_Buy;
	pInputCombAction.Volume = 1;
	string __combdirection;
	std::cout << "0-������ϣ�1-������" << std::endl;
	std::cin >> __combdirection;
	if (__combdirection == "0")
	{
		pInputCombAction.CombDirection = THOST_FTDC_CMDR_Comb;
		int b = m_pTrader->ReqCombActionInsert(&pInputCombAction, RequestID++);
		LOG((b == 0) ? "�����������¼������......���ͳɹ�\n" : "�����������¼������......����ʧ�ܣ��������=[%d]\n", b);
	}
	else if (__combdirection == "1")
	{
		pInputCombAction.CombDirection = THOST_FTDC_CMDR_UnComb;
		string __combtradeid;
		std::cout << "����������ϱ�ţ�" << std::endl;
		std::cin >> __combtradeid;
		strcpy_s(pInputCombAction.ComTradeID, __combtradeid.c_str());
		int b = m_pTrader->ReqCombActionInsert(&pInputCombAction, RequestID++);
		LOG((b == 0) ? "���������¼������......���ͳɹ�\n" : "���������¼������......����ʧ�ܣ��������=[%d]\n", b);
	}
	else
	{
		LOG("��Ч��ѡ��!\n");
	}

//#ifdef __WIN_SYS
//	WaitForSingleObject(m_ReqCombActionInsert_signal, INFINITE);
//#elif defined(__UNIX_SYS)
//	sem_wait(&m_ReqCombActionInsert_signal);
//#endif // __WIN_SYS
}

void CUser::ReqQryOrder()
{
	CThostFtdcQryOrderField pQryOrder;
	memset(&pQryOrder, 0, sizeof(CThostFtdcQryOrderField));
	strcpy(pQryOrder.BrokerID, m_BrokerID);
	strcpy(pQryOrder.InvestorID, m_InvestorID);
	strcpy(pQryOrder.InstrumentID, m_InstrumentID);

	int a = m_pTrader->ReqQryOrder(&pQryOrder, RequestID++);
	LOG((a == 0) ? "�����ѯ����......���ͳɹ�[%d]\n" : "�����ѯ����......����ʧ�ܣ��������=[%d]\n", a);

//#ifdef __WIN_SYS
//	WaitForSingleObject(m_ReqQryOrder_signal, INFINITE);
//#elif defined(__UNIX_SYS)
//	sem_wait(&m_ReqQryOrder_signal);
//#endif // __WIN_SYS
}

void CUser::ReqQryTrade()
{
	CThostFtdcQryTradeField pQryTrade;
	memset(&pQryTrade, 0, sizeof(CThostFtdcQryTradeField));
	strcpy(pQryTrade.BrokerID, m_BrokerID);
	strcpy(pQryTrade.InvestorID, m_InvestorID);
	strcpy(pQryTrade.InstrumentID, m_InstrumentID);

	int a = m_pTrader->ReqQryTrade(&pQryTrade, RequestID++);
	LOG((a == 0) ? "�����ѯ�ɽ�......���ͳɹ�[%d]\n" : "�����ѯ�ɽ�......����ʧ�ܣ��������=[%d]\n", a);

//#ifdef __WIN_SYS
//	WaitForSingleObject(m_ReqQryTrade_signal, INFINITE);
//#elif defined(__UNIX_SYS)
//	sem_wait(&m_ReqQryTrade_signal);
//#endif // __WIN_SYS
}

void CUser::ReqQryInvestorPosition()
{
	CThostFtdcQryInvestorPositionField pQryInvestorPosition;
	memset(&pQryInvestorPosition, 0, sizeof(CThostFtdcQryInvestorPositionField));
	strcpy(pQryInvestorPosition.BrokerID, m_BrokerID);
	strcpy(pQryInvestorPosition.InvestorID, m_InvestorID);
	//strcpy(pQryInvestorPosition.InstrumentID, m_InstrumentID);

	int a = m_pTrader->ReqQryInvestorPosition(&pQryInvestorPosition, RequestID++);
	LOG((a == 0) ? "�����ѯͶ���ֲ߳�......���ͳɹ�[%d]\n" : "�����ѯͶ���ֲ߳�......����ʧ�ܣ��������=[%d]\n", a);

//#ifdef __WIN_SYS
//	WaitForSingleObject(m_ReqQryInvestorPosition_signal, INFINITE);
//#elif defined(__UNIX_SYS)
//	sem_wait(&m_ReqQryInvestorPosition_signal);
//#endif // __WIN_SYS
}

void CUser::ReqQryTradingAccount()
{
	CThostFtdcQryTradingAccountField pQryTradingAccount;
	memset(&pQryTradingAccount, 0, sizeof(CThostFtdcQryTradingAccountField));
	strcpy(pQryTradingAccount.BrokerID, m_BrokerID);
	strcpy(pQryTradingAccount.InvestorID, m_InvestorID);
	strcpy(pQryTradingAccount.CurrencyID, "CNY");

	int a = m_pTrader->ReqQryTradingAccount(&pQryTradingAccount, RequestID++);
	LOG((a == 0) ? "�����ѯ�ʽ��˻�......���ͳɹ�[%d]\n" : "�����ѯ�ʽ��˻�......����ʧ�ܣ��������=[%d]\n", a);

//#ifdef __WIN_SYS
//	WaitForSingleObject(m_ReqQryTradingAccount_signal, INFINITE);
//#elif defined(__UNIX_SYS)
//	sem_wait(&m_ReqQryTradingAccount_signal);
//#endif // __WIN_SYS
}

void CUser::ReqQryInvestor()
{
	CThostFtdcQryInvestorField pQryInvestor;
	memset(&pQryInvestor, 0, sizeof(CThostFtdcQryInvestorField));
	strcpy(pQryInvestor.BrokerID, m_BrokerID);
	strcpy(pQryInvestor.InvestorID, m_InvestorID);
	int a = m_pTrader->ReqQryInvestor(&pQryInvestor, RequestID++);
	LOG((a == 0) ? "�����ѯ�ʽ��˻�......���ͳɹ�[%d]\n" : "�����ѯ�ʽ��˻�......����ʧ�ܣ��������=[%d]\n", a);

//#ifdef __WIN_SYS
//	WaitForSingleObject(m_ReqQryInvestor_signal, INFINITE);
//#elif defined(__UNIX_SYS)
//	sem_wait(&m_ReqQryInvestor_signal);
//#endif // __WIN_SYS

}

void CUser::ReqQryTradingCode()
{
	CThostFtdcQryTradingCodeField pQryTradingCode;
	memset(&pQryTradingCode, 0, sizeof(CThostFtdcQryTradingCodeField));
	strcpy(pQryTradingCode.BrokerID, m_BrokerID);
	strcpy(pQryTradingCode.InvestorID, m_InvestorID);
	pQryTradingCode.ClientIDType = THOST_FTDC_CIDT_Speculation;
	int a = m_pTrader->ReqQryTradingCode(&pQryTradingCode, RequestID++);
	LOG((a == 0) ? "�����ѯ���ױ���......���ͳɹ�\n" : "�����ѯ���ױ���......����ʧ�ܣ��������=[%d]\n", a);

//#ifdef __WIN_SYS
//	WaitForSingleObject(m_ReqQryTradingCode_signal, INFINITE);
//#elif defined(__UNIX_SYS)
//	sem_wait(&m_ReqQryTradingCode_signal);
//#endif // __WIN_SYS
}

void CUser::ReqQryInstrumentMarginRate()
{
	CThostFtdcQryInstrumentMarginRateField pQryInstrumentMarginRate;
	memset(&pQryInstrumentMarginRate, 0, sizeof(CThostFtdcQryInstrumentMarginRateField));
	strcpy(pQryInstrumentMarginRate.BrokerID, m_BrokerID);
	strcpy(pQryInstrumentMarginRate.InvestorID, m_InvestorID);
	//strcpy(pQryInstrumentMarginRate.InstrumentID, m_InstrumentID);

	int a = m_pTrader->ReqQryInstrumentMarginRate(&pQryInstrumentMarginRate, RequestID++);
	LOG((a == 0) ? "�����ѯ��Լ��֤����......���ͳɹ�\n" : "�����ѯ��Լ��֤����......����ʧ�ܣ��������=[%d]\n", a);

//#ifdef __WIN_SYS
//	WaitForSingleObject(m_ReqQryInstrumentMarginRate_signal, INFINITE);
//#elif defined(__UNIX_SYS)
//	sem_wait(&m_ReqQryInstrumentMarginRate_signal);
//#endif // __WIN_SYS
}

void CUser::ReqQryInstrumentCommissionRate()
{
	CThostFtdcQryInstrumentCommissionRateField pQryInstrumentCommissionRate;
	memset(&pQryInstrumentCommissionRate, 0, sizeof(CThostFtdcQryInstrumentCommissionRateField));
	strcpy(pQryInstrumentCommissionRate.BrokerID, m_BrokerID);
	strcpy(pQryInstrumentCommissionRate.InvestorID, m_InvestorID);
	//
	strcpy(pQryInstrumentCommissionRate.InstrumentID, m_InstrumentID);

	int a = m_pTrader->ReqQryInstrumentCommissionRate(&pQryInstrumentCommissionRate, RequestID++);
	LOG((a == 0) ? "�����ѯ��Լ��������......���ͳɹ�\n" : "�����ѯ��Լ��������......����ʧ�ܣ��������=[%d]\n", a);

//#ifdef __WIN_SYS
//	WaitForSingleObject(m_ReqQryInstrumentCommissionRate_signal, INFINITE);
//#elif defined(__UNIX_SYS)
//	sem_wait(&m_ReqQryInstrumentCommissionRate_signal);
//#endif // __WIN_SYS
}

void CUser::ReqQryExchange()
{
	CThostFtdcQryExchangeField pQryExchange;
	memset(&pQryExchange, 0, sizeof(CThostFtdcQryExchangeField));

	string __exchangeid;
	string __chosen;
	std::cout << "��ѡ������: 1.SSE  ����.SZSE" << std::endl;
	std::cin >> __chosen;
	(__chosen == "1") ? __exchangeid = "SSE" : __exchangeid = "SZSE";
	strcpy(pQryExchange.ExchangeID, __exchangeid.c_str());

	int a = m_pTrader->ReqQryExchange(&pQryExchange, RequestID++);
	LOG((a == 0) ? "�����ѯ������......���ͳɹ�\n" : "�����ѯ������......����ʧ�ܣ��������=[%d]\n", a);

//#ifdef __WIN_SYS
//	WaitForSingleObject(m_ReqQryExchange_signal, INFINITE);
//#elif defined(__UNIX_SYS)
//	sem_wait(&m_ReqQryExchange_signal);
//#endif // __WIN_SYS
}

void CUser::ReqQryProduct()
{
	CThostFtdcQryProductField pQryProduct;
	memset(&pQryProduct, 0, sizeof(CThostFtdcQryProductField));

	string __productid;
	std::cout << "�������Ʒ����: ";
	std::cin >> __productid;
	strcpy(pQryProduct.ProductID, __productid.c_str());

	int a = m_pTrader->ReqQryProduct(&pQryProduct, RequestID++);
	LOG((a == 0) ? "�����ѯ��Ʒ......���ͳɹ�\n" : "�����ѯ��Ʒ......����ʧ�ܣ��������=[%d]\n", a);

//#ifdef __WIN_SYS
//	WaitForSingleObject(m_ReqQryProduct_signal, INFINITE);
//#elif defined(__UNIX_SYS)
//	sem_wait(&m_ReqQryProduct_signal);
//#endif // __WIN_SYS
}

void CUser::ReqQryInstrument()
{
	CThostFtdcQryInstrumentField pQryInstrument;
	memset(&pQryInstrument, 0, sizeof(CThostFtdcQryInstrumentField));
	strcpy(pQryInstrument.InstrumentID, m_InstrumentID);
	
	int a = m_pTrader->ReqQryInstrument(&pQryInstrument, RequestID++);
	LOG((a == 0) ? "��ѯ��Լ����......���ͳɹ�[%d]\n" : "��ѯ��Լ����......����ʧ�ܣ��������=[%d]\n", a);

//#ifdef __WIN_SYS
//	WaitForSingleObject(m_ReqQryInstrument_signal, INFINITE);
//#elif defined(__UNIX_SYS)
//	sem_wait(&m_ReqQryInstrument_signal);
//#endif // __WIN_SYS
}

void CUser::ReqQryDepthMarketData()
{
	CThostFtdcQryDepthMarketDataField pQryDepthMarketData;
	memset(&pQryDepthMarketData, 0, sizeof(CThostFtdcQryDepthMarketDataField));
	strcpy(pQryDepthMarketData.InstrumentID, m_InstrumentID);
	int a = m_pTrader->ReqQryDepthMarketData(&pQryDepthMarketData, RequestID++);
	LOG((a == 0) ? "�����ѯ����......���ͳɹ�[%d]\n" : "�����ѯ����......����ʧ�ܣ��������=[%d]\n", a);

//#ifdef __WIN_SYS
//	WaitForSingleObject(m_ReqQryDepthMarketData_signal, INFINITE);
//#elif defined(__UNIX_SYS)
//	sem_wait(&m_ReqQryDepthMarketData_signal);
//#endif // __WIN_SYS
}

void CUser::ReqQrySettlementInfo()
{
	CThostFtdcQrySettlementInfoField pQrySettlementInfo;
	memset(&pQrySettlementInfo, 0, sizeof(CThostFtdcQrySettlementInfoField));
	strcpy(pQrySettlementInfo.BrokerID, m_BrokerID);
	strcpy(pQrySettlementInfo.InvestorID, m_InvestorID);

	string _tradingday;
	std::cout << "�����뽻����,��ʽΪyyyymmdd: ";
	std::cin >> _tradingday;
	strcpy(pQrySettlementInfo.TradingDay, _tradingday.c_str());
	int a = m_pTrader->ReqQrySettlementInfo(&pQrySettlementInfo, RequestID++);
	LOG((a == 0) ? "�����ѯͶ���߽�����......���ͳɹ�[%d]\n" : "�����ѯͶ���߽�����......����ʧ�ܣ��������=[%d]\n", a);

//#ifdef __WIN_SYS
//	WaitForSingleObject(m_ReqQrySettlementInfo_signal, INFINITE);
//#elif defined(__UNIX_SYS)
//	sem_wait(&m_ReqQrySettlementInfo_signal);
//#endif // __WIN_SYS
}

void CUser::ReqQryTransferBank()
{
	CThostFtdcQryTransferBankField pQryTransferBank;
	memset(&pQryTransferBank, 0, sizeof(CThostFtdcQryTransferBankField));
	int a = m_pTrader->ReqQryTransferBank(&pQryTransferBank, RequestID++);
	LOG((a == 0) ? "�����ѯת������......���ͳɹ�[%d]\n" : "�����ѯת������......����ʧ�ܣ��������=[%d]\n", a);

//#ifdef __WIN_SYS
//	WaitForSingleObject(m_ReqQryTransferBank_signal, INFINITE);
//#elif defined(__UNIX_SYS)
//	sem_wait(&m_ReqQryTransferBank_signal);
//#endif // __WIN_SYS
}

void CUser::ReqQryInvestorPositionDetail()
{
	CThostFtdcQryInvestorPositionDetailField pQryInvestorPositionDetail;
	memset(&pQryInvestorPositionDetail, 0, sizeof(CThostFtdcQryInvestorPositionDetailField));
	strcpy(pQryInvestorPositionDetail.BrokerID, m_BrokerID);
	strcpy(pQryInvestorPositionDetail.InvestorID, m_InvestorID);
	strcpy(pQryInvestorPositionDetail.InstrumentID, m_InstrumentID);

	int a = m_pTrader->ReqQryInvestorPositionDetail(&pQryInvestorPositionDetail, RequestID++);
	LOG((a == 0) ? "�����ѯͶ���ֲ߳���ϸ......���ͳɹ�[%d]\n" : "�����ѯͶ���ֲ߳���ϸ......����ʧ�ܣ��������=[%d]\n", a);

//#ifdef __WIN_SYS
//	WaitForSingleObject(m_ReqQryInvestorPositionDetail_signal, INFINITE);
//#elif defined(__UNIX_SYS)
//	sem_wait(&m_ReqQryInvestorPositionDetail_signal);
//#endif // __WIN_SYS
}

void CUser::ReqQryNotice()
{
	CThostFtdcQryNoticeField pQryNotice;
	memset(&pQryNotice, 0, sizeof(CThostFtdcQryNoticeField));
	strcpy(pQryNotice.BrokerID, m_BrokerID);

	int a = m_pTrader->ReqQryNotice(&pQryNotice, RequestID++);
	LOG((a == 0) ? "�����ѯ�ͻ�֪ͨ......���ͳɹ�[%d]\n" : "�����ѯ�ͻ�֪ͨ......����ʧ�ܣ��������=[%d]\n", a);

//#ifdef __WIN_SYS
//	WaitForSingleObject(m_ReqQryNotice_signal, INFINITE);
//#elif defined(__UNIX_SYS)
//	sem_wait(&m_ReqQryNotice_signal);
//#endif // __WIN_SYS
}

void CUser::ReqQrySettlementInfoConfirm()
{
	CThostFtdcQrySettlementInfoConfirmField pQrySettlementInfoConfirm;
	memset(&pQrySettlementInfoConfirm, 0, sizeof(CThostFtdcQrySettlementInfoConfirmField));
	strcpy(pQrySettlementInfoConfirm.BrokerID, m_BrokerID);
	strcpy(pQrySettlementInfoConfirm.InvestorID, m_InvestorID);
	strcpy(pQrySettlementInfoConfirm.CurrencyID, "CNY");
	int a = m_pTrader->ReqQrySettlementInfoConfirm(&pQrySettlementInfoConfirm, RequestID++);
	LOG((a == 0) ? "�����ѯ������Ϣȷ��......���ͳɹ�[%d]\n" : "�����ѯ������Ϣȷ��......����ʧ�ܣ��������=[%d]\n", a);

//#ifdef __WIN_SYS
//	WaitForSingleObject(m_ReqQrySettlementInfoConfirm_signal, INFINITE);
//#elif defined(__UNIX_SYS)
//	sem_wait(&m_ReqQrySettlementInfoConfirm_signal);
//#endif // __WIN_SYS
}

void CUser::ReqQryInvestorPositionCombineDetail()
{
	CThostFtdcQryInvestorPositionCombineDetailField pQryInvestorPositionCombineDetail;
	memset(&pQryInvestorPositionCombineDetail, 0, sizeof(CThostFtdcQryInvestorPositionCombineDetailField));
	strcpy(pQryInvestorPositionCombineDetail.BrokerID, m_BrokerID);
	strcpy(pQryInvestorPositionCombineDetail.InvestorID, m_InvestorID);
	int a = m_pTrader->ReqQryInvestorPositionCombineDetail(&pQryInvestorPositionCombineDetail, RequestID++);
	LOG((a == 0) ? "�����ѯ������Ϣȷ��......���ͳɹ�[%d]\n" : "�����ѯ������Ϣȷ��......����ʧ�ܣ��������=[%d]\n", a);

//#ifdef __WIN_SYS
//	WaitForSingleObject(m_ReqQryInvestorPositionCombineDetail_signal, INFINITE);
//#elif defined(__UNIX_SYS)
//	sem_wait(&m_ReqQryInvestorPositionCombineDetail_signal);
//#endif // __WIN_SYS
}

void CUser::ReqQryCFMMCTradingAccountKey()
{
	CThostFtdcQryCFMMCTradingAccountKeyField pQryCFMMCTradingAccountKey;
	memset(&pQryCFMMCTradingAccountKey, 0, sizeof(CThostFtdcQryCFMMCTradingAccountKeyField));
	strcpy(pQryCFMMCTradingAccountKey.BrokerID, m_BrokerID);
	strcpy(pQryCFMMCTradingAccountKey.InvestorID, m_InvestorID);

	int a = m_pTrader->ReqQryCFMMCTradingAccountKey(&pQryCFMMCTradingAccountKey, RequestID++);
	LOG((a == 0) ? "�����ѯ��֤����ϵͳ���͹�˾�ʽ��˻���Կ......���ͳɹ�[%d]\n" : "�����ѯ��֤����ϵͳ���͹�˾�ʽ��˻���Կ......����ʧ�ܣ��������=[%d]\n", a);

//#ifdef __WIN_SYS
//	WaitForSingleObject(m_ReqQryCFMMCTradingAccountKey_signal, INFINITE);
//#elif defined(__UNIX_SYS)
//	sem_wait(&m_ReqQryCFMMCTradingAccountKey_signal);
//#endif // __WIN_SYS
}

void CUser::ReqQryEWarrantOffset()
{
	CThostFtdcQryEWarrantOffsetField pQryEWarrantOffset;
	memset(&pQryEWarrantOffset, 0, sizeof(CThostFtdcQryEWarrantOffsetField));
	strcpy(pQryEWarrantOffset.BrokerID, m_BrokerID);
	strcpy(pQryEWarrantOffset.InvestorID, m_InvestorID);

	int a = m_pTrader->ReqQryEWarrantOffset(&pQryEWarrantOffset, RequestID++);
	LOG((a == 0) ? "�����ѯ�ֵ��۵���Ϣ......���ͳɹ�[%d]\n" : "�����ѯ�ֵ��۵���Ϣ......����ʧ�ܣ��������=[%d]\n", a);

//#ifdef __WIN_SYS
//	WaitForSingleObject(m_ReqQryEWarrantOffset_signal, INFINITE);
//#elif defined(__UNIX_SYS)
//	sem_wait(&m_ReqQryEWarrantOffset_signal);
//#endif // __WIN_SYS
}

void CUser::ReqQryInvestorProductGroupMargin()
{
	CThostFtdcQryInvestorProductGroupMarginField pQryInvestorProductGroupMargin;
	memset(&pQryInvestorProductGroupMargin, 0, sizeof(CThostFtdcQryInvestorProductGroupMarginField));
	strcpy(pQryInvestorProductGroupMargin.BrokerID, m_BrokerID);
	strcpy(pQryInvestorProductGroupMargin.InvestorID, m_InvestorID);

	int a = m_pTrader->ReqQryInvestorProductGroupMargin(&pQryInvestorProductGroupMargin, RequestID++);
	LOG((a == 0) ? "�����ѯͶ����Ʒ��/��Ʒ�ֱ�֤��......���ͳɹ�[%d]\n" : "�����ѯͶ����Ʒ��/��Ʒ�ֱ�֤��......����ʧ�ܣ��������=[%d]\n", a);

//#ifdef __WIN_SYS
//	WaitForSingleObject(m_ReqQryInvestorProductGroupMargin_signal, INFINITE);
//#elif defined(__UNIX_SYS)
//	sem_wait(&m_ReqQryInvestorProductGroupMargin_signal);
//#endif // __WIN_SYS

}

void CUser::ReqQryExchangeMarginRate()
{
	CThostFtdcQryExchangeMarginRateField pQryExchangeMarginRate;
	memset(&pQryExchangeMarginRate, 0, sizeof(CThostFtdcQryExchangeMarginRateField));
	strcpy(pQryExchangeMarginRate.BrokerID, m_BrokerID);
	strcpy(pQryExchangeMarginRate.InstrumentID, m_InstrumentID);

	int a = m_pTrader->ReqQryExchangeMarginRate(&pQryExchangeMarginRate, RequestID++);
	LOG((a == 0) ? "�����ѯ��������֤����......���ͳɹ�[%d]\n" : "�����ѯ��������֤����......����ʧ�ܣ��������=[%d]\n", a);

//#ifdef __WIN_SYS
//	WaitForSingleObject(m_ReqQryExchangeMarginRate_signal, INFINITE);
//#elif defined(__UNIX_SYS)
//	sem_wait(&m_ReqQryExchangeMarginRate_signal);
//#endif // __WIN_SYS
}

void CUser::ReqQryExchangeMarginRateAdjust()
{
	CThostFtdcQryExchangeMarginRateAdjustField pQryExchangeMarginRateAdjust;
	memset(&pQryExchangeMarginRateAdjust, 0, sizeof(CThostFtdcQryExchangeMarginRateAdjustField));
	strcpy(pQryExchangeMarginRateAdjust.BrokerID, m_BrokerID);
	strcpy(pQryExchangeMarginRateAdjust.InstrumentID, m_InstrumentID);

	int a = m_pTrader->ReqQryExchangeMarginRateAdjust(&pQryExchangeMarginRateAdjust, RequestID++);
	LOG((a == 0) ? "�����ѯ������������֤����......���ͳɹ�[%d]\n" : "�����ѯ������������֤����......����ʧ�ܣ��������=[%d]\n", a);

//#ifdef __WIN_SYS
//	WaitForSingleObject(m_ReqQryExchangeMarginRateAdjust_signal, INFINITE);
//#elif defined(__UNIX_SYS)
//	sem_wait(&m_ReqQryExchangeMarginRateAdjust_signal);
//#endif // __WIN_SYS
}

void CUser::ReqQryExchangeRate()
{
	CThostFtdcQryExchangeRateField pQryExchangeRate;
	memset(&pQryExchangeRate, 0, sizeof(CThostFtdcQryExchangeRateField));
	strcpy(pQryExchangeRate.BrokerID, m_BrokerID);
	strcpy(pQryExchangeRate.ToCurrencyID, "USD");
	strcpy(pQryExchangeRate.FromCurrencyID, "CNY");

	int a = m_pTrader->ReqQryExchangeRate(&pQryExchangeRate, RequestID++);
	LOG((a == 0) ? "�����ѯ����......���ͳɹ�[%d]\n" : "�����ѯ����......����ʧ�ܣ��������=[%d]\n", a);

//#ifdef __WIN_SYS
//	WaitForSingleObject(m_ReqQryExchangeRate_signal, INFINITE);
//#elif defined(__UNIX_SYS)
//	sem_wait(&m_ReqQryExchangeRate_signal);
//#endif // __WIN_SYS

}


void CUser::ReqQryProductExchRate()
{
	CThostFtdcQryProductExchRateField pQryProductExchRate;
	memset(&pQryProductExchRate, 0, sizeof(CThostFtdcQryProductExchRateField));
	strcpy(pQryProductExchRate.ExchangeID, "SSE");
	strcpy(pQryProductExchRate.ProductID, "xxx");
	int a = m_pTrader->ReqQryProductExchRate(&pQryProductExchRate, RequestID++);
	LOG((a == 0) ? "�����ѯ��Ʒ���ۻ���......���ͳɹ�[%d]\n" : "�����ѯ��Ʒ���ۻ���......����ʧ�ܣ��������=[%d]\n", a);

}

void CUser::ReqQryProductGroup()
{
	CThostFtdcQryProductGroupField pQryProductGroup;
	memset(&pQryProductGroup, 0, sizeof(CThostFtdcQryProductGroupField));
	strcpy(pQryProductGroup.ExchangeID, "SSE");
	strcpy(pQryProductGroup.ProductID, "xxx");
	int a = m_pTrader->ReqQryProductGroup(&pQryProductGroup, RequestID++);
	LOG((a == 0) ? "�����ѯ��Ʒ��......���ͳɹ�[%d]\n" : "�����ѯ��Ʒ��......����ʧ�ܣ��������=[%d]\n", a);

}

void CUser::ReqQryMMInstrumentCommissionRate()
{
	CThostFtdcQryMMInstrumentCommissionRateField pQryMMInstrumentCommissionRate;
	memset(&pQryMMInstrumentCommissionRate, 0, sizeof(CThostFtdcQryMMInstrumentCommissionRateField));
	strcpy(pQryMMInstrumentCommissionRate.BrokerID, m_BrokerID);
	strcpy(pQryMMInstrumentCommissionRate.InvestorID, m_InvestorID);
	strcpy(pQryMMInstrumentCommissionRate.InstrumentID, m_InstrumentID);

	int a = m_pTrader->ReqQryMMInstrumentCommissionRate(&pQryMMInstrumentCommissionRate, RequestID++);
	LOG((a == 0) ? "�����ѯ�����̺�Լ��������......���ͳɹ�[%d]\n" : "�����ѯ�����̺�Լ��������......����ʧ�ܣ��������=[%d]\n", a);

//#ifdef __WIN_SYS
//	WaitForSingleObject(m_ReqQryMMInstrumentCommissionRate_signal, INFINITE);
//#elif defined(__UNIX_SYS)
//	sem_wait(&m_ReqQryMMInstrumentCommissionRate_signal);
//#endif // __WIN_SYS
}

void CUser::ReqQryMMOptionInstrCommRate()
{
	CThostFtdcQryMMOptionInstrCommRateField pQryMMOptionInstrCommRate;
	memset(&pQryMMOptionInstrCommRate, 0, sizeof(CThostFtdcQryMMOptionInstrCommRateField));
	strcpy(pQryMMOptionInstrCommRate.BrokerID, m_BrokerID);
	strcpy(pQryMMOptionInstrCommRate.InvestorID, m_InvestorID);
	strcpy(pQryMMOptionInstrCommRate.InstrumentID, m_InstrumentID);

	int a = m_pTrader->ReqQryMMOptionInstrCommRate(&pQryMMOptionInstrCommRate, RequestID++);
	LOG((a == 0) ? "�����ѯ��������Ȩ��Լ������......���ͳɹ�[%d]\n" : "�����ѯ��������Ȩ��Լ������......����ʧ�ܣ��������=[%d]\n", a);

//#ifdef __WIN_SYS
//	WaitForSingleObject(m_ReqQryMMOptionInstrCommRate_signal, INFINITE);
//#elif defined(__UNIX_SYS)
//	sem_wait(&m_ReqQryMMOptionInstrCommRate_signal);
//#endif // __WIN_SYS
}

void CUser::ReqQryInstrumentOrderCommRate()
{
	CThostFtdcQryInstrumentOrderCommRateField pQryInstrumentOrderCommRate;
	memset(&pQryInstrumentOrderCommRate, 0, sizeof(CThostFtdcQryInstrumentOrderCommRateField));
	strcpy(pQryInstrumentOrderCommRate.BrokerID, m_BrokerID);
	strcpy(pQryInstrumentOrderCommRate.InvestorID, m_InvestorID);
	//strcpy(pQryInstrumentOrderCommRate.InstrumentID, m_InstrumentID);

	int a = m_pTrader->ReqQryInstrumentOrderCommRate(&pQryInstrumentOrderCommRate, RequestID++);
	LOG((a == 0) ? "�����ѯ����������......���ͳɹ�[%d]\n" : "�����ѯ����������......����ʧ�ܣ��������=[%d]\n", a);

////#ifdef __WIN_SYS
////	WaitForSingleObject(m_ReqQryInstrumentOrderCommRate_signal, INFINITE);
////#elif defined(__UNIX_SYS)
////	sem_wait(&m_ReqQryInstrumentOrderCommRate_signal);
////#endif // __WIN_SYS
}

void CUser::ReqQryOptionInstrTradeCost()
{
	CThostFtdcQryOptionInstrTradeCostField pQryOptionInstrTradeCost;
	memset(&pQryOptionInstrTradeCost, 0, sizeof(CThostFtdcQryOptionInstrTradeCostField));
	strcpy(pQryOptionInstrTradeCost.BrokerID, m_BrokerID);
	strcpy(pQryOptionInstrTradeCost.InvestorID, m_InvestorID);
	strcpy(pQryOptionInstrTradeCost.InstrumentID, m_InstrumentID);

	int a = m_pTrader->ReqQryOptionInstrTradeCost(&pQryOptionInstrTradeCost, RequestID++);
	LOG((a == 0) ? "�����ѯ��Ȩ���׳ɱ�......���ͳɹ�[%d]\n" : "�����ѯ��Ȩ���׳ɱ�......����ʧ�ܣ��������=[%d]\n", a);

////#ifdef __WIN_SYS
////	WaitForSingleObject(m_ReqQryOptionInstrTradeCost_signal, INFINITE);
////#elif defined(__UNIX_SYS)
////	sem_wait(&m_ReqQryOptionInstrTradeCost_signal);
////#endif // __WIN_SYS

}

void CUser::ReqQryOptionInstrCommRate()
{
	CThostFtdcQryOptionInstrCommRateField pQryOptionInstrCommRate;
	memset(&pQryOptionInstrCommRate, 0, sizeof(CThostFtdcQryOptionInstrCommRateField));
	strcpy(pQryOptionInstrCommRate.BrokerID, m_BrokerID);
	strcpy(pQryOptionInstrCommRate.InvestorID, m_InvestorID);
	strcpy(pQryOptionInstrCommRate.InstrumentID, m_InstrumentID);

	int a = m_pTrader->ReqQryOptionInstrCommRate(&pQryOptionInstrCommRate, RequestID++);
	LOG((a == 0) ? "�����ѯ��Ȩ��Լ������......���ͳɹ�[%d]\n" : "�����ѯ��Ȩ��Լ������......����ʧ�ܣ��������=[%d]\n", a);

//#ifdef __WIN_SYS
//	WaitForSingleObject(m_ReqQryOptionInstrCommRate_signal, INFINITE);
//#elif defined(__UNIX_SYS)
//	sem_wait(&m_ReqQryOptionInstrCommRate_signal);
//#endif // __WIN_SYS
}

void CUser::ReqQryExecOrder()
{
	CThostFtdcQryExecOrderField pQryExecOrder;
	memset(&pQryExecOrder, 0, sizeof(CThostFtdcQryExecOrderField));
	strcpy(pQryExecOrder.BrokerID, m_BrokerID);
	strcpy(pQryExecOrder.InvestorID, m_InvestorID);
	strcpy(pQryExecOrder.InstrumentID, m_InstrumentID);

	int a = m_pTrader->ReqQryExecOrder(&pQryExecOrder, RequestID++);
	LOG((a == 0) ? "�����ѯִ������......���ͳɹ�[%d]\n" : "�����ѯִ������......����ʧ�ܣ��������=[%d]\n", a);

//#ifdef __WIN_SYS
//	WaitForSingleObject(m_ReqQryExecOrder_signal, INFINITE);
//#elif defined(__UNIX_SYS)
//	sem_wait(&m_ReqQryExecOrder_signal);
//#endif // __WIN_SYS
}

void CUser::ReqQryForQuote()
{
	CThostFtdcQryForQuoteField pQryForQuote;
	memset(&pQryForQuote, 0, sizeof(CThostFtdcQryForQuoteField));
	strcpy(pQryForQuote.BrokerID, m_BrokerID);
	strcpy(pQryForQuote.InvestorID, m_InvestorID);
	strcpy(pQryForQuote.InstrumentID, m_InstrumentID);

	int a = m_pTrader->ReqQryForQuote(&pQryForQuote, RequestID++);
	LOG((a == 0) ? "�����ѯѯ��......���ͳɹ�[%d]\n" : "�����ѯѯ��......����ʧ�ܣ��������=[%d]\n", a);

//#ifdef __WIN_SYS
//	WaitForSingleObject(m_ReqQryForQuote_signal, INFINITE);
//#elif defined(__UNIX_SYS)
//	sem_wait(&m_ReqQryForQuote_signal);
//#endif // __WIN_SYS
}

void CUser::ReqQryQuote()
{
	CThostFtdcQryQuoteField pQryQuote;
	memset(&pQryQuote, 0, sizeof(CThostFtdcQryQuoteField));
	strcpy(pQryQuote.BrokerID, m_BrokerID);
	strcpy(pQryQuote.InvestorID, m_InvestorID);
	strcpy(pQryQuote.InstrumentID, m_InstrumentID);

	int a = m_pTrader->ReqQryQuote(&pQryQuote, RequestID++);
	LOG((a == 0) ? "�����ѯ����......���ͳɹ�[%d]\n" : "�����ѯ����......����ʧ�ܣ��������=[%d]\n", a);

//#ifdef __WIN_SYS
//	WaitForSingleObject(m_ReqQryQuote_signal, INFINITE);
//#elif defined(__UNIX_SYS)
//	sem_wait(&m_ReqQryQuote_signal);
//#endif // __WIN_SYS
}

void CUser::ReqQryLock()
{
	CThostFtdcQryLockField pQryLock;
	memset(&pQryLock, 0, sizeof(CThostFtdcQryLockField));
	strcpy(pQryLock.BrokerID, m_BrokerID);
	strcpy(pQryLock.InvestorID, m_InvestorID);
	strcpy(pQryLock.InstrumentID, m_InstrumentID);

	int a = m_pTrader->ReqQryLock(&pQryLock, RequestID++);
	LOG((a == 0) ? "�����ѯ����......���ͳɹ�[%d]\n" : "�����ѯ����......����ʧ�ܣ��������=[%d]\n", a);

//#ifdef __WIN_SYS
//	WaitForSingleObject(m_ReqQryLock_signal, INFINITE);
//#elif defined(__UNIX_SYS)
//	sem_wait(&m_ReqQryLock_signal);
//#endif // __WIN_SYS
}

void CUser::ReqQryLockPosition()
{
	CThostFtdcQryLockPositionField pQryLockPosition;
	memset(&pQryLockPosition, 0, sizeof(CThostFtdcQryLockPositionField));
	strcpy(pQryLockPosition.BrokerID, m_BrokerID);
	strcpy(pQryLockPosition.InvestorID, m_InvestorID);
	strcpy(pQryLockPosition.InstrumentID, m_InstrumentID);

	int a = m_pTrader->ReqQryLockPosition(&pQryLockPosition, RequestID++);
	LOG((a == 0) ? "�����ѯ����......���ͳɹ�[%d]\n" : "�����ѯ����......����ʧ�ܣ��������=[%d]\n", a);

//#ifdef __WIN_SYS
//	WaitForSingleObject(m_ReqQryLockPosition_signal, INFINITE);
//#elif defined(__UNIX_SYS)
//	sem_wait(&m_ReqQryLock_signal);
//#endif // __WIN_SYS
}

void CUser::ReqQryETFOptionInstrCommRate()
{
	CThostFtdcQryETFOptionInstrCommRateField pQryETFOptionInstrCommRate;
	memset(&pQryETFOptionInstrCommRate, 0, sizeof(CThostFtdcQryETFOptionInstrCommRateField));
	strcpy(pQryETFOptionInstrCommRate.BrokerID, m_BrokerID);
	strcpy(pQryETFOptionInstrCommRate.InvestorID, m_InvestorID);
	strcpy(pQryETFOptionInstrCommRate.InstrumentID, m_InstrumentID);

	int a = m_pTrader->ReqQryETFOptionInstrCommRate(&pQryETFOptionInstrCommRate, RequestID++);
	LOG((a == 0) ? "ETF��Ȩ�������ʲ�ѯ......���ͳɹ�[%d]\n" : "ETF��Ȩ�������ʲ�ѯ......����ʧ�ܣ��������=[%d]\n", a);

//#ifdef __WIN_SYS
//	WaitForSingleObject(m_ReqQryETFOptionInstrCommRate_signal, INFINITE);
//#elif defined(__UNIX_SYS)
//	sem_wait(&m_ReqQryETFOptionInstrCommRate_signal);
//#endif // __WIN_SYS
}

void CUser::ReqQryInvestorLevel()
{
	CThostFtdcQryInvestorLevelField pQryInvestorLevel;
	memset(&pQryInvestorLevel, 0, sizeof(CThostFtdcQryInvestorLevelField));
	strcpy(pQryInvestorLevel.BrokerID, m_BrokerID);
	strcpy(pQryInvestorLevel.InvestorID, m_InvestorID);

	int a = m_pTrader->ReqQryInvestorLevel(&pQryInvestorLevel, RequestID++);
	LOG((a == 0) ? "�����ѯͶ���߷ּ�......���ͳɹ�[%d]\n" : "�����ѯͶ���߷ּ�......����ʧ�ܣ��������=[%d]\n", a);

//#ifdef __WIN_SYS
//	WaitForSingleObject(m_ReqQryInvestorLevel_signal, INFINITE);
//#elif defined(__UNIX_SYS)
//	sem_wait(&m_ReqQryInvestorLevel_signal);
//#endif // __WIN_SYS
}

void CUser::ReqQryExecFreeze()
{
	CThostFtdcQryExecFreezeField pQryExecFreeze;
	memset(&pQryExecFreeze, 0, sizeof(CThostFtdcQryExecFreezeField));
	strcpy(pQryExecFreeze.BrokerID, m_BrokerID);
	strcpy(pQryExecFreeze.InvestorID, m_InvestorID);

	int a = m_pTrader->ReqQryExecFreeze(&pQryExecFreeze, RequestID++);
	LOG((a == 0) ? "�����ѯE+1����Ȩ����......���ͳɹ�[%d]\n" : "�����ѯE+1����Ȩ����......����ʧ�ܣ��������=[%d]\n", a);

//#ifdef __WIN_SYS
//	WaitForSingleObject(m_ReqQryExecFreeze_signal, INFINITE);
//#elif defined(__UNIX_SYS)
//	sem_wait(&m_ReqQryExecFreeze_signal);
//#endif // __WIN_SYS
}

void CUser::ReqQryCombInstrumentGuard()
{
	CThostFtdcQryCombInstrumentGuardField pQryCombInstrumentGuard;
	memset(&pQryCombInstrumentGuard, 0, sizeof(CThostFtdcQryCombInstrumentGuardField));

	strcpy(pQryCombInstrumentGuard.BrokerID, m_BrokerID);
	strcpy(pQryCombInstrumentGuard.InstrumentID, m_InstrumentID);

	int a = m_pTrader->ReqQryCombInstrumentGuard(&pQryCombInstrumentGuard, RequestID++);
	LOG((a == 0) ? "�����ѯ��Ϻ�Լ��ȫϵ��......���ͳɹ�[%d]\n" : "�����ѯ��Ϻ�Լ��ȫϵ��......����ʧ�ܣ��������=[%d]\n", a);

//#ifdef __WIN_SYS
//	WaitForSingleObject(m_ReqQryCombInstrumentGuard_signal, INFINITE);
//#elif defined(__UNIX_SYS)
//	sem_wait(&m_ReqQryCombInstrumentGuard_signal);
//#endif // __WIN_SYS
}

void CUser::ReqQryCombAction()
{
	CThostFtdcQryCombActionField pQryCombAction;
	memset(&pQryCombAction, 0, sizeof(CThostFtdcQryCombActionField));
	strcpy(pQryCombAction.BrokerID, m_BrokerID);
	strcpy(pQryCombAction.InvestorID, m_InvestorID);

	int a = m_pTrader->ReqQryCombAction(&pQryCombAction, RequestID++);
	LOG((a == 0) ? "�����ѯ�������......���ͳɹ�[%d]\n" : "�����ѯ�������......����ʧ�ܣ��������=[%d]\n", a);

//#ifdef __WIN_SYS
//	WaitForSingleObject(m_ReqQryCombAction_signal, INFINITE);
//#elif defined(__UNIX_SYS)
//	sem_wait(&m_ReqQryCombAction_signal);
//#endif // __WIN_SYS
}

void CUser::ReqQryTransferSerial()
{
	CThostFtdcQryTransferSerialField pQryTransferSerial;
	memset(&pQryTransferSerial, 0, sizeof(CThostFtdcQryTransferSerialField));
	strcpy(pQryTransferSerial.BrokerID, m_BrokerID);
	strcpy(pQryTransferSerial.AccountID, m_InvestorID);

	int a = m_pTrader->ReqQryTransferSerial(&pQryTransferSerial, RequestID++);
	LOG((a == 0) ? "�����ѯת����ˮ......���ͳɹ�[%d]\n" : "�����ѯת����ˮ......����ʧ�ܣ��������=[%d]\n", a);

//#ifdef __WIN_SYS
//	WaitForSingleObject(m_ReqQryTransferSerial_signal, INFINITE);
//#elif defined(__UNIX_SYS)
//	sem_wait(&m_ReqQryTransferSerial_signal);
//#endif // __WIN_SYS

}

void CUser::ReqQryAccountregister()
{
	CThostFtdcQryAccountregisterField pQryAccountregister;
	memset(&pQryAccountregister, 0, sizeof(CThostFtdcQryAccountregisterField));
	strcpy(pQryAccountregister.BrokerID, m_BrokerID);
	strcpy(pQryAccountregister.AccountID, m_InvestorID);

	int a = m_pTrader->ReqQryAccountregister(&pQryAccountregister, RequestID++);
	LOG((a == 0) ? "�����ѯ����ǩԼ��ϵ......���ͳɹ�[%d]\n" : "�����ѯ����ǩԼ��ϵ......����ʧ�ܣ��������=[%d]\n", a);

//#ifdef __WIN_SYS
//	WaitForSingleObject(m_ReqQryAccountregister_signal, INFINITE);
//#elif defined(__UNIX_SYS)
//	sem_wait(&m_ReqQryAccountregister_signal);
//#endif // __WIN_SYS
}

void CUser::ReqQryContractBank()
{
	CThostFtdcQryContractBankField pQryContractBank;
	memset(&pQryContractBank, 0, sizeof(CThostFtdcQryContractBankField));
	strcpy(pQryContractBank.BrokerID, m_BrokerID);

	int a = m_pTrader->ReqQryContractBank(&pQryContractBank, RequestID++);
	LOG((a == 0) ? "�����ѯǩԼ����......���ͳɹ�[%d]\n" : "�����ѯǩԼ����......����ʧ�ܣ��������=[%d]\n", a);

//#ifdef __WIN_SYS
//	WaitForSingleObject(m_ReqQryContractBank_signal, INFINITE);
//#elif defined(__UNIX_SYS)
//	sem_wait(&m_ReqQryContractBank_signal);
//#endif // __WIN_SYS
}

void CUser::ReqQryParkedOrder()
{

}

void CUser::ReqQryParkedOrderAction()
{

}

void CUser::ReqQryTradingNotice()
{
	CThostFtdcQryTradingNoticeField pQryTradingNotice;
	memset(&pQryTradingNotice, 0, sizeof(CThostFtdcQryTradingNoticeField));
	strcpy(pQryTradingNotice.BrokerID, m_BrokerID);
	strcpy(pQryTradingNotice.InvestorID, m_InvestorID);

	int a = m_pTrader->ReqQryTradingNotice(&pQryTradingNotice, RequestID++);
	LOG((a == 0) ? "�����ѯ����֪ͨ......���ͳɹ�[%d]\n" : "�����ѯ����֪ͨ......����ʧ�ܣ��������=[%d]\n", a);

//#ifdef __WIN_SYS
//	WaitForSingleObject(m_ReqQryTradingNotice_signal, INFINITE);
//#elif defined(__UNIX_SYS)
//	sem_wait(&m_ReqQryTradingNotice_signal);
//#endif // __WIN_SYS

}

void CUser::ReqQryBrokerTradingParams()
{
	CThostFtdcQryBrokerTradingParamsField pQryBrokerTradingParams;
	memset(&pQryBrokerTradingParams, 0, sizeof(CThostFtdcQryBrokerTradingParamsField));
	strcpy(pQryBrokerTradingParams.BrokerID, m_BrokerID);
	strcpy(pQryBrokerTradingParams.InvestorID, m_InvestorID);

	int a = m_pTrader->ReqQryBrokerTradingParams(&pQryBrokerTradingParams, RequestID++);
	LOG((a == 0) ? "�����ѯ���͹�˾���ײ���......���ͳɹ�[%d]\n" : "�����ѯ���͹�˾���ײ���......����ʧ�ܣ��������=[%d]\n", a);

//#ifdef __WIN_SYS
//	WaitForSingleObject(m_ReqQryBrokerTradingParams_signal, INFINITE);
//#elif defined(__UNIX_SYS)
//	sem_wait(&m_ReqQryBrokerTradingParams_signal);
//#endif // __WIN_SYS

}

void CUser::ReqQryBrokerTradingAlgos()
{
	CThostFtdcQryBrokerTradingAlgosField pQryBrokerTradingAlgos;
	memset(&pQryBrokerTradingAlgos, 0, sizeof(CThostFtdcQryBrokerTradingAlgosField));
	strcpy(pQryBrokerTradingAlgos.BrokerID, m_BrokerID);

	int a = m_pTrader->ReqQryBrokerTradingAlgos(&pQryBrokerTradingAlgos, RequestID++);
	LOG((a == 0) ? "�����ѯ���͹�˾�����㷨......���ͳɹ�[%d]\n" : "�����ѯ���͹�˾�����㷨......����ʧ�ܣ��������=[%d]\n", a);

//#ifdef __WIN_SYS
//	WaitForSingleObject(m_ReqQryBrokerTradingAlgos_signal, INFINITE);
//#elif defined(__UNIX_SYS)
//	sem_wait(&m_ReqQryBrokerTradingAlgos_signal);
//#endif // __WIN_SYS
}


void CUser::ReqFromBankToFutureByFuture()
{
	CThostFtdcReqTransferField pReqTransfer;
	memset(&pReqTransfer, 0, sizeof(CThostFtdcReqTransferField));

	strcpy(pReqTransfer.BrokerID, m_BrokerID);
	strcpy(pReqTransfer.TradeCode, "xxxxx");
	pReqTransfer.LastFragment = THOST_FTDC_LF_Yes; 
	pReqTransfer.IdCardType = THOST_FTDC_ICT_IDCard; 
	pReqTransfer.CustType = THOST_FTDC_CUSTT_Person;
	string _bankaccount;
	std::cout << "���������п���: ";
	std::cin >> _bankaccount;
	strcpy(pReqTransfer.BankAccount, _bankaccount.c_str());
	strcpy(pReqTransfer.AccountID, m_InvestorID);
	strcpy(pReqTransfer.Password, m_Password);
	int a = m_pTrader->ReqFromBankToFutureByFuture(&pReqTransfer, RequestID++);
	LOG((a == 0) ? "�ڻ����������ʽ�ת�ڻ�����......���ͳɹ�[%d]\n" : "�ڻ����������ʽ�ת�ڻ�����......����ʧ�ܣ��������=[%d]\n", a);
}

void CUser::ReqFromFutureToBankByFuture()
{
	CThostFtdcReqTransferField pReqTransfer;
	memset(&pReqTransfer, 0, sizeof(CThostFtdcReqTransferField));

	strcpy(pReqTransfer.BrokerID, m_BrokerID);
	strcpy(pReqTransfer.TradeCode, "xxxxx");
	pReqTransfer.LastFragment = THOST_FTDC_LF_Yes;
	pReqTransfer.IdCardType = THOST_FTDC_ICT_IDCard;
	pReqTransfer.CustType = THOST_FTDC_CUSTT_Person;
	string _bankaccount;
	std::cout << "���������п���: ";
	std::cin >> _bankaccount;
	strcpy(pReqTransfer.BankAccount, _bankaccount.c_str());
	strcpy(pReqTransfer.AccountID, m_InvestorID);
	strcpy(pReqTransfer.Password, m_Password);

	int a = m_pTrader->ReqFromFutureToBankByFuture(&pReqTransfer, RequestID++);
	LOG((a == 0) ? "�ڻ������ڻ��ʽ�ת��������......���ͳɹ�[%d]\n" : "�ڻ������ڻ��ʽ�ת��������......����ʧ�ܣ��������=[%d]\n", a);
}

void CUser::ReqQueryBankAccountMoneyByFuture()
{
	CThostFtdcReqQueryAccountField pReqQueryAccount;
	memset(&pReqQueryAccount, 0, sizeof(CThostFtdcReqQueryAccountField));

	int a = m_pTrader->ReqQueryBankAccountMoneyByFuture(&pReqQueryAccount, RequestID++);
	LOG((a == 0) ? "�ڻ������ѯ�����������......���ͳɹ�[%d]\n" : "�ڻ������ѯ�����������......����ʧ�ܣ��������=[%d]\n", a);
}

void CUser::ReqExecCombineOrderAction()
{
	CThostFtdcInputExecCombineOrderActionField pInputExecCombineOrderAction;
	memset(&pInputExecCombineOrderAction, 0, sizeof(CThostFtdcInputExecCombineOrderActionField));

	strcpy(pInputExecCombineOrderAction.BrokerID, m_BrokerID);
	strcpy(pInputExecCombineOrderAction.InvestorID, m_InvestorID);
	pInputExecCombineOrderAction.ExecCombineOrderActionRef = 0;
	//strcpy(pInputExecCombineOrderAction.ExecCombineOrderRef, "1");
	//pInputExecCombineOrderAction.FrontID = 1;
	//pInputExecCombineOrderAction.SessionID = 1;
	string __exchangeid;
	string __chosen;
	std::cout << "��ѡ������: 1.SSE  ����.SZSE" << endl;
	std::cin >> __chosen;
	(__chosen == "1") ? __exchangeid = "SSE" : __exchangeid = "SZSE";
	strcpy(pInputExecCombineOrderAction.ExchangeID, __exchangeid.c_str());
	string __ordersysid;
	std::cout << "�����뱨�����(OrderSysID):" << endl;
	std::cin >> __ordersysid;
	strcpy(pInputExecCombineOrderAction.ExecCombineOrderSysID, __ordersysid.c_str());
	pInputExecCombineOrderAction.ActionFlag = THOST_FTDC_AF_Delete;

	int a = m_pTrader->ReqExecCombineOrderAction(&pInputExecCombineOrderAction, RequestID++);
	LOG((a == 0) ? "��Ȩָ��ϲ���������......���ͳɹ�[%d]\n" : "��Ȩָ��ϲ���������......����ʧ�ܣ��������=[%d]\n", a);
}

void CUser::ReqQryExecCombineOrder()
{
	CThostFtdcQryExecCombineOrderField pQryExecCombineOrder;
	memset(&pQryExecCombineOrder, 0, sizeof(CThostFtdcQryExecCombineOrderField));

	int a = m_pTrader->ReqQryExecCombineOrder(&pQryExecCombineOrder, RequestID++);
	LOG((a == 0) ? "�����ѯ��Ȩָ��ϲ�......���ͳɹ�[%d]\n" : "�����ѯ��Ȩָ��ϲ�......����ʧ�ܣ��������=[%d]\n", a);
}

void CUser::ReqInternalTransfer()
{
	CThostFtdcInputInternalTransferField pInputInternalTransfer;
	memset(&pInputInternalTransfer, 0, sizeof(CThostFtdcInputInternalTransferField));
	strcpy(pInputInternalTransfer.BrokerID, m_BrokerID);
	strcpy(pInputInternalTransfer.UserID, m_UserID);
	strcpy(pInputInternalTransfer.InvestorID, m_InvestorID);
	strcpy(pInputInternalTransfer.InternalTransferRef, "1");
	std::cout << "��������Ȩ�ʽ�����: ";
	string _OpPassWord;
	std::cin >> _OpPassWord;
	strcpy(pInputInternalTransfer.OpPassWord, _OpPassWord.c_str());
	std::cout << "�������ʽ���ת���: ";
	string _Amount;
	std::cin >> _Amount;
	pInputInternalTransfer.Amount = atoi(_Amount.c_str());
	strcpy(pInputInternalTransfer.FuBrokerID, m_BrokerID);
	std::cout << "�������ڻ�Ͷ�����˺�: ";
	string _FuInvestorID;
	std::cin >> _FuInvestorID;
	strcpy(pInputInternalTransfer.FuInvestorID, _FuInvestorID.c_str());
	std::cout << "�������ڻ��ʽ�����: ";
	string _FuPassWord;
	std::cin >> _FuPassWord;
	strcpy(pInputInternalTransfer.FuPassWord, _FuPassWord.c_str());
	strcpy(pInputInternalTransfer.CurrencyID, "CNY");

	pInputInternalTransfer.Direction = THOST_FTDC_INTERFDDIREC_FundIn;

	int a = m_pTrader->ReqInternalTransfer(&pInputInternalTransfer, RequestID++);
	LOG((a == 0) ? "�����ʽ���ת......���ͳɹ�[%d]\n" : "�����ʽ���ת......����ʧ�ܣ��������=[%d]\n", a);

}

void CUser::ReqQryLimitAmount()
{
	CThostFtdcQryLimitAmountField pQryLimitAmount;
	memset(&pQryLimitAmount, 0, sizeof(CThostFtdcQryLimitAmountField));
	strcpy(pQryLimitAmount.BrokerID, m_BrokerID);
	strcpy(pQryLimitAmount.ExchangeID, "SZSE");
	strcpy(pQryLimitAmount.InvestorID, m_InvestorID);
	int a = m_pTrader->ReqQryLimitAmount(&pQryLimitAmount, RequestID++);
	LOG((a == 0) ? "�����ѯ�������......���ͳɹ�[%d]\n" : "�����ѯ�������......����ʧ�ܣ��������=[%d]\n", a);

}

void CUser::ReqQryLimitPosi()
{
	CThostFtdcQryLimitPosiField pQryLimitPosi;
	memset(&pQryLimitPosi, 0, sizeof(CThostFtdcQryLimitPosiField));

	strcpy(pQryLimitPosi.BrokerID, m_BrokerID);
	strcpy(pQryLimitPosi.ExchangeID, "SSE");
	strcpy(pQryLimitPosi.InvestorID, m_InvestorID);
	//strcpy(pQryLimitPosi.InstrumentID, m_InstrumentID);
	int a = m_pTrader->ReqQryLimitPosi(&pQryLimitPosi, RequestID++);
	LOG((a == 0) ? "�����ѯ�ֲ�����......���ͳɹ�[%d]\n" : "�����ѯ�ֲ�����......����ʧ�ܣ��������=[%d]\n", a);
}

void CUser::OnFrontConnected()
{
	CTraderSpi::OnFrontConnected();
#ifdef __WIN_SYS
	SetEvent(m_Init_signal);
#elif defined(__UNIX_SYS)
	sem_post(&m_Init_signal);
#endif // __WIN_SYS
}

void CUser::OnFrontDisconnected(int nReason)
{
	CTraderSpi::OnFrontDisconnected(nReason);
}

void CUser::OnHeartBeatWarning(int nTimeLapse)
{
	CTraderSpi::OnHeartBeatWarning(nTimeLapse);
}

void CUser::OnRspAuthenticate(CThostFtdcRspAuthenticateField * pRspAuthenticateField, CThostFtdcRspInfoField * pRspInfo, int nRequestID, bool bIsLast)
{
	CTraderSpi::OnRspAuthenticate(pRspAuthenticateField, pRspInfo, nRequestID, bIsLast);

	if (bIsLast)
	{
#ifdef __WIN_SYS
		SetEvent(m_ReqAuthenticate_signal);
#elif defined(__UNIX_SYS)
		sem_post(&m_ReqAuthenticate_signal);
#endif // __WIN_SYS
	}
}

void CUser::OnRspUserLogin(CThostFtdcRspUserLoginField * pRspUserLogin, CThostFtdcRspInfoField * pRspInfo, int nRequestID, bool bIsLast)
{
	CTraderSpi::OnRspUserLogin(pRspUserLogin, pRspInfo, nRequestID, bIsLast);
	if(pRspInfo->ErrorID != 0)
	{
		m_loginflag = false;
	}
	else
	{
		m_loginflag = true;
	}
	if (bIsLast)
	{
#ifdef __WIN_SYS
		SetEvent(m_ReqUserLogin_signal);
#elif defined(__UNIX_SYS)
		sem_post(&m_ReqUserLogin_signal);
#endif // __WIN_SYS
	}
}

void CUser::OnRspUserLogout(CThostFtdcUserLogoutField * pUserLogout, CThostFtdcRspInfoField * pRspInfo, int nRequestID, bool bIsLast)
{
	CTraderSpi::OnRspUserLogout(pUserLogout, pRspInfo, nRequestID, bIsLast);

	if (bIsLast)
	{
#ifdef __WIN_SYS
		SetEvent(m_ReqUserLogout_signal);
#elif defined(__UNIX_SYS)
		sem_post(&m_ReqUserLogout_signal);
#endif // __WIN_SYS
	}
}

void CUser::OnRspUserPasswordUpdate(CThostFtdcUserPasswordUpdateField * pUserPasswordUpdate, CThostFtdcRspInfoField * pRspInfo, int nRequestID, bool bIsLast)
{
	CTraderSpi::OnRspUserPasswordUpdate(pUserPasswordUpdate, pRspInfo, nRequestID, bIsLast);

	if (bIsLast)
	{
#ifdef __WIN_SYS
		SetEvent(m_ReqUserPasswordUpdate_signal);
#elif defined(__UNIX_SYS)
		sem_post(&m_ReqUserPasswordUpdate_signal);
#endif // __WIN_SYS
	}

}

void CUser::OnRspTradingAccountPasswordUpdate(CThostFtdcTradingAccountPasswordUpdateField * pTradingAccountPasswordUpdate, CThostFtdcRspInfoField * pRspInfo, int nRequestID, bool bIsLast)
{
	CTraderSpi::OnRspTradingAccountPasswordUpdate(pTradingAccountPasswordUpdate, pRspInfo, nRequestID, bIsLast);

	if (bIsLast)
	{
#ifdef __WIN_SYS
		SetEvent(m_ReqTradingAccountPasswordUpdate_signal);
#elif defined(__UNIX_SYS)
		sem_post(&m_ReqTradingAccountPasswordUpdate_signal);
#endif // __WIN_SYS
	}

}

void CUser::OnRspOrderInsert(CThostFtdcInputOrderField * pInputOrder, CThostFtdcRspInfoField * pRspInfo, int nRequestID, bool bIsLast)
{
	CTraderSpi::OnRspOrderInsert(pInputOrder, pRspInfo, nRequestID, bIsLast);

//#ifdef __WIN_SYS
//	SetEvent(m_ReqOrderInsert_signal);
//#elif defined(__UNIX_SYS)
//	sem_post(&m_ReqOrderInsert_signal);
//#endif // __WIN_SYS
}

void CUser::OnRspParkedOrderInsert(CThostFtdcParkedOrderField * pParkedOrder, CThostFtdcRspInfoField * pRspInfo, int nRequestID, bool bIsLast)
{
	CTraderSpi::OnRspParkedOrderInsert(pParkedOrder, pRspInfo, nRequestID, bIsLast);

//#ifdef __WIN_SYS
//	SetEvent(m_ReqParkedOrderInsert_signal);
//#elif defined(__UNIX_SYS)
//	sem_post(&m_ReqParkedOrderInsert_signal);
//#endif // __WIN_SYS
}

void CUser::OnRspParkedOrderAction(CThostFtdcParkedOrderActionField * pParkedOrderAction, CThostFtdcRspInfoField * pRspInfo, int nRequestID, bool bIsLast)
{
	CTraderSpi::OnRspParkedOrderAction(pParkedOrderAction, pRspInfo, nRequestID, bIsLast);

//#ifdef __WIN_SYS
//	SetEvent(m_ReqParkedOrderAction_signal);
//#elif defined(__UNIX_SYS)
//	sem_post(&m_ReqParkedOrderAction_signal);
//#endif // __WIN_SYS
}

void CUser::OnRspOrderAction(CThostFtdcInputOrderActionField * pInputOrderAction, CThostFtdcRspInfoField * pRspInfo, int nRequestID, bool bIsLast)
{
	CTraderSpi::OnRspOrderAction(pInputOrderAction, pRspInfo, nRequestID, bIsLast);

//#ifdef __WIN_SYS
//	SetEvent(m_ReqOrderAction_signal);
//#elif defined(__UNIX_SYS)
//	sem_post(&m_ReqOrderAction_signal);
//#endif // __WIN_SYS
}

void CUser::OnRspQueryMaxOrderVolume(CThostFtdcQueryMaxOrderVolumeField * pQueryMaxOrderVolume, CThostFtdcRspInfoField * pRspInfo, int nRequestID, bool bIsLast)
{
	CTraderSpi::OnRspQueryMaxOrderVolume(pQueryMaxOrderVolume, pRspInfo, nRequestID, bIsLast);

//#ifdef __WIN_SYS
//	SetEvent(m_ReqQueryMaxOrderVolume_signal);
//#elif defined(__UNIX_SYS)
//	sem_post(&m_ReqQueryMaxOrderVolume_signal);
//#endif // __WIN_SYS
}

void CUser::OnRspSettlementInfoConfirm(CThostFtdcSettlementInfoConfirmField * pSettlementInfoConfirm, CThostFtdcRspInfoField * pRspInfo, int nRequestID, bool bIsLast)
{
	CTraderSpi::OnRspSettlementInfoConfirm(pSettlementInfoConfirm, pRspInfo, nRequestID, bIsLast);

	if (bIsLast)
	{
#ifdef __WIN_SYS
		SetEvent(m_ReqSettlementInfoConfirm_signal);
#elif defined(__UNIX_SYS)
		sem_post(&m_ReqSettlementInfoConfirm_signal);
#endif // __WIN_SYS
	}
}


void CUser::OnRspRemoveParkedOrder(CThostFtdcRemoveParkedOrderField *pRemoveParkedOrder, CThostFtdcRspInfoField *pRspInfo, int nRequestID, bool bIsLast)
{
	CTraderSpi::OnRspRemoveParkedOrder(pRemoveParkedOrder, pRspInfo, nRequestID, bIsLast);
	if (bIsLast)
	{
//#ifdef __WIN_SYS
//		SetEvent(m_ReqRemoveParkedOrder_signal);
//#elif defined(__UNIX_SYS)
//		sem_post(&m_ReqRemoveParkedOrder_signal);
//#endif // __WIN_SYS		
	}

}

void CUser::OnRspRemoveParkedOrderAction(CThostFtdcRemoveParkedOrderActionField *pRemoveParkedOrderAction, CThostFtdcRspInfoField *pRspInfo, int nRequestID, bool bIsLast)
{
	CTraderSpi::OnRspRemoveParkedOrderAction(pRemoveParkedOrderAction, pRspInfo, nRequestID, bIsLast);
	if (bIsLast)
	{
//#ifdef __WIN_SYS
//		SetEvent(m_ReqRemoveParkedOrderAction_signal);
//#elif defined(__UNIX_SYS)
//		sem_post(&m_ReqRemoveParkedOrderAction_signal);
//#endif // __WIN_SYS		
	}
}

void CUser::OnRspExecOrderInsert(CThostFtdcInputExecOrderField *pInputExecOrder, CThostFtdcRspInfoField *pRspInfo, int nRequestID, bool bIsLast)
{
	CTraderSpi::OnRspExecOrderInsert(pInputExecOrder, pRspInfo, nRequestID, bIsLast);
	if (bIsLast)
	{
//#ifdef __WIN_SYS
//		SetEvent(m_ReqExecOrderInsert_signal);
//#elif defined(__UNIX_SYS)
//		sem_post(&m_ReqExecOrderInsert_signal);
//#endif // __WIN_SYS		
	}
}

void CUser::OnRspExecOrderAction(CThostFtdcInputExecOrderActionField *pInputExecOrderAction, CThostFtdcRspInfoField *pRspInfo, int nRequestID, bool bIsLast)
{
	CTraderSpi::OnRspExecOrderAction(pInputExecOrderAction, pRspInfo, nRequestID, bIsLast);
	if (bIsLast)
	{
//#ifdef __WIN_SYS
//		SetEvent(m_ReqExecOrderAction_signal);
//#elif defined(__UNIX_SYS)
//		sem_post(&m_ReqExecOrderAction_signal);
//#endif // __WIN_SYS		
	}
}

void CUser::OnRspForQuoteInsert(CThostFtdcInputForQuoteField *pInputForQuote, CThostFtdcRspInfoField *pRspInfo, int nRequestID, bool bIsLast)
{
	CTraderSpi::OnRspForQuoteInsert(pInputForQuote, pRspInfo, nRequestID, bIsLast);
	if (bIsLast)
	{
//#ifdef __WIN_SYS
//		SetEvent(m_ReqForQuoteInsert_signal);
//#elif defined(__UNIX_SYS)
//		sem_post(&m_ReqForQuoteInsert_signal);
//#endif // __WIN_SYS		
	}
}

void CUser::OnRspQuoteInsert(CThostFtdcInputQuoteField *pInputQuote, CThostFtdcRspInfoField *pRspInfo, int nRequestID, bool bIsLast)
{
	CTraderSpi::OnRspQuoteInsert(pInputQuote, pRspInfo, nRequestID, bIsLast);
	if (bIsLast)
	{
//#ifdef __WIN_SYS
//		SetEvent(m_ReqQuoteInsert_signal);
//#elif defined(__UNIX_SYS)
//		sem_post(&m_ReqQuoteInsert_signal);
//#endif // __WIN_SYS		
	}
}

void CUser::OnRspQuoteAction(CThostFtdcInputQuoteActionField *pInputQuoteAction, CThostFtdcRspInfoField *pRspInfo, int nRequestID, bool bIsLast)
{
	CTraderSpi::OnRspQuoteAction(pInputQuoteAction, pRspInfo, nRequestID, bIsLast);
	if (bIsLast)
	{
//#ifdef __WIN_SYS
//		SetEvent(m_ReqQuoteAction_signal);
//#elif defined(__UNIX_SYS)
//		sem_post(&m_ReqQuoteAction_signal);
//#endif // __WIN_SYS		
	}
}

void CUser::OnRspLockInsert(CThostFtdcInputLockField *pInputLock, CThostFtdcRspInfoField *pRspInfo, int nRequestID, bool bIsLast)
{
	CTraderSpi::OnRspLockInsert(pInputLock, pRspInfo, nRequestID, bIsLast);
	if (bIsLast)
	{
//#ifdef __WIN_SYS
//		SetEvent(m_ReqLockInsert_signal);
//#elif defined(__UNIX_SYS)
//		sem_post(&m_ReqLockInsert_signal);
//#endif // __WIN_SYS		
	}
}

void CUser::OnRspBatchOrderAction(CThostFtdcInputBatchOrderActionField *pInputBatchOrderAction, CThostFtdcRspInfoField *pRspInfo, int nRequestID, bool bIsLast)
{
	CTraderSpi::OnRspBatchOrderAction(pInputBatchOrderAction, pRspInfo, nRequestID, bIsLast);
	if (bIsLast)
	{
//#ifdef __WIN_SYS
//		SetEvent(m_ReqBatchOrderAction_signal);
//#elif defined(__UNIX_SYS)
//		sem_post(&m_ReqBatchOrderAction_signal);
//#endif // __WIN_SYS		
	}
}

void CUser::OnRspCombActionInsert(CThostFtdcInputCombActionField *pInputCombAction, CThostFtdcRspInfoField *pRspInfo, int nRequestID, bool bIsLast)
{
	CTraderSpi::OnRspCombActionInsert(pInputCombAction, pRspInfo, nRequestID, bIsLast);
	if (bIsLast)
	{
//#ifdef __WIN_SYS
//		SetEvent(m_ReqCombActionInsert_signal);
//#elif defined(__UNIX_SYS)
//		sem_post(&m_ReqCombActionInsert_signal);
//#endif // __WIN_SYS		
	}
}

void CUser::OnRspQryOrder(CThostFtdcOrderField *pOrder, CThostFtdcRspInfoField *pRspInfo, int nRequestID, bool bIsLast)
{
	CTraderSpi::OnRspQryOrder(pOrder, pRspInfo, nRequestID, bIsLast);
	if (bIsLast)
	{
//#ifdef __WIN_SYS
//		SetEvent(m_ReqQryOrder_signal);
//#elif defined(__UNIX_SYS)
//		sem_post(&m_ReqQryOrder_signal);
//#endif // __WIN_SYS		
	}
}

void CUser::OnRspQryTrade(CThostFtdcTradeField *pTrade, CThostFtdcRspInfoField *pRspInfo, int nRequestID, bool bIsLast)
{
	CTraderSpi::OnRspQryTrade(pTrade, pRspInfo, nRequestID, bIsLast);
	if (bIsLast)
	{
//#ifdef __WIN_SYS
//		SetEvent(m_ReqQryTrade_signal);
//#elif defined(__UNIX_SYS)
//		sem_post(&m_ReqQryTrade_signal);
//#endif // __WIN_SYS		
	}
}

void CUser::OnRspQryInvestorPosition(CThostFtdcInvestorPositionField *pInvestorPosition, CThostFtdcRspInfoField *pRspInfo, int nRequestID, bool bIsLast)
{
	CTraderSpi::OnRspQryInvestorPosition(pInvestorPosition, pRspInfo, nRequestID, bIsLast);
	if (bIsLast)
	{
//#ifdef __WIN_SYS
//		SetEvent(m_ReqQryInvestorPosition_signal);
//#elif defined(__UNIX_SYS)
//		sem_post(&m_ReqQryInvestorPosition_signal);
//#endif // __WIN_SYS		
	}
}

void CUser::OnRspQryTradingAccount(CThostFtdcTradingAccountField *pTradingAccount, CThostFtdcRspInfoField *pRspInfo, int nRequestID, bool bIsLast)
{
	CTraderSpi::OnRspQryTradingAccount(pTradingAccount, pRspInfo, nRequestID, bIsLast);
//	if (bIsLast)
//	{
//#ifdef __WIN_SYS
//		SetEvent(m_ReqQryInvestorPosition_signal);
//#elif defined(__UNIX_SYS)
//		sem_post(&m_ReqQryInvestorPosition_signal);
//#endif // __WIN_SYS		
//	}
}

void CUser::OnRspQryInvestor(CThostFtdcInvestorField *pInvestor, CThostFtdcRspInfoField *pRspInfo, int nRequestID, bool bIsLast)
{
	CTraderSpi::OnRspQryInvestor(pInvestor, pRspInfo, nRequestID, bIsLast);
//	if (bIsLast)
//	{
//#ifdef __WIN_SYS
//		SetEvent(m_ReqQryInvestor_signal);
//#elif defined(__UNIX_SYS)
//		sem_post(&m_ReqQryInvestor_signal);
//#endif // __WIN_SYS		
//	}
}

void CUser::OnRspQryTradingCode(CThostFtdcTradingCodeField *pTradingCode, CThostFtdcRspInfoField *pRspInfo, int nRequestID, bool bIsLast)
{
	CTraderSpi::OnRspQryTradingCode(pTradingCode, pRspInfo, nRequestID, bIsLast);
//	if (bIsLast)
//	{
//#ifdef __WIN_SYS
//		SetEvent(m_ReqQryTradingCode_signal);
//#elif defined(__UNIX_SYS)
//		sem_post(&m_ReqQryTradingCode_signal);
//#endif // __WIN_SYS		
//	}
}

void CUser::OnRspQryInstrumentMarginRate(CThostFtdcInstrumentMarginRateField *pInstrumentMarginRate, CThostFtdcRspInfoField *pRspInfo, int nRequestID, bool bIsLast)
{
	CTraderSpi::OnRspQryInstrumentMarginRate(pInstrumentMarginRate, pRspInfo, nRequestID, bIsLast);
//	if (bIsLast)
//	{
////#ifdef __WIN_SYS
//		SetEvent(m_ReqQryInstrumentMarginRate_signal);
////#elif defined(__UNIX_SYS)
//		sem_post(&m_ReqQryInstrumentMarginRate_signal);
////#endif // __WIN_SYS		
//	}
}

void CUser::OnRspQryInstrumentCommissionRate(CThostFtdcInstrumentCommissionRateField *pInstrumentCommissionRate, CThostFtdcRspInfoField *pRspInfo, int nRequestID, bool bIsLast)
{
	CTraderSpi::OnRspQryInstrumentCommissionRate(pInstrumentCommissionRate, pRspInfo, nRequestID, bIsLast);
//	if (bIsLast)
//	{
////#ifdef __WIN_SYS
//		SetEvent(m_ReqQryInstrumentCommissionRate_signal);
////#elif defined(__UNIX_SYS)
//		sem_post(&m_ReqQryInstrumentCommissionRate_signal);
////#endif // __WIN_SYS		
//	}
}

void CUser::OnRspQryExchange(CThostFtdcExchangeField *pExchange, CThostFtdcRspInfoField *pRspInfo, int nRequestID, bool bIsLast)
{
	CTraderSpi::OnRspQryExchange(pExchange, pRspInfo, nRequestID, bIsLast);
	if (bIsLast)
	{
//#ifdef __WIN_SYS
//		SetEvent(m_ReqQryExchange_signal);
//#elif defined(__UNIX_SYS)
//		sem_post(&m_ReqQryExchange_signal);
//#endif // __WIN_SYS		
	}
}

void CUser::OnRspQryProduct(CThostFtdcProductField *pProduct, CThostFtdcRspInfoField *pRspInfo, int nRequestID, bool bIsLast)
{
	CTraderSpi::OnRspQryProduct(pProduct, pRspInfo, nRequestID, bIsLast);
	if (bIsLast)
	{
//#ifdef __WIN_SYS
//		SetEvent(m_ReqQryProduct_signal);
//#elif defined(__UNIX_SYS)
//		sem_post(&m_ReqQryProduct_signal);
//#endif // __WIN_SYS		
	}
}

void CUser::OnRspQryInstrument(CThostFtdcInstrumentField *pInstrument, CThostFtdcRspInfoField *pRspInfo, int nRequestID, bool bIsLast)
{
	CTraderSpi::OnRspQryInstrument(pInstrument, pRspInfo, nRequestID, bIsLast);
	if (bIsLast)
	{
//#ifdef __WIN_SYS
//		SetEvent(m_ReqQryInstrument_signal);
//#elif defined(__UNIX_SYS)
//		sem_post(&m_ReqQryInstrument_signal);
//#endif // __WIN_SYS		
	}
}

void CUser::OnRspQryDepthMarketData(CThostFtdcDepthMarketDataField *pDepthMarketData, CThostFtdcRspInfoField *pRspInfo, int nRequestID, bool bIsLast)
{
	CTraderSpi::OnRspQryDepthMarketData(pDepthMarketData, pRspInfo, nRequestID, bIsLast);
	if (bIsLast)
	{
//#ifdef __WIN_SYS
//		SetEvent(m_ReqQryDepthMarketData_signal);
//#elif defined(__UNIX_SYS)
//		sem_post(&m_ReqQryDepthMarketData_signal);
//#endif // __WIN_SYS		
	}
}

void CUser::OnRspQrySettlementInfo(CThostFtdcSettlementInfoField *pSettlementInfo, CThostFtdcRspInfoField *pRspInfo, int nRequestID, bool bIsLast)
{
	CTraderSpi::OnRspQrySettlementInfo(pSettlementInfo, pRspInfo, nRequestID, bIsLast);
	if (bIsLast)
	{
//#ifdef __WIN_SYS
//		SetEvent(m_ReqQrySettlementInfo_signal);
//#elif defined(__UNIX_SYS)
//		sem_post(&m_ReqQrySettlementInfo_signal);
//#endif // __WIN_SYS		
	}
}

void CUser::OnRspQryTransferBank(CThostFtdcTransferBankField *pTransferBank, CThostFtdcRspInfoField *pRspInfo, int nRequestID, bool bIsLast)
{
	CTraderSpi::OnRspQryTransferBank(pTransferBank, pRspInfo, nRequestID, bIsLast);
	if (bIsLast)
	{
//#ifdef __WIN_SYS
//		SetEvent(m_ReqQryTransferBank_signal);
//#elif defined(__UNIX_SYS)
//		sem_post(&m_ReqQryTransferBank_signal);
//#endif // __WIN_SYS		
	}
}

void CUser::OnRspQryInvestorPositionDetail(CThostFtdcInvestorPositionDetailField *pInvestorPositionDetail, CThostFtdcRspInfoField *pRspInfo, int nRequestID, bool bIsLast)
{
	CTraderSpi::OnRspQryInvestorPositionDetail(pInvestorPositionDetail, pRspInfo, nRequestID, bIsLast);
	if (bIsLast)
	{
//#ifdef __WIN_SYS
//		SetEvent(m_ReqQryInvestorPositionDetail_signal);
//#elif defined(__UNIX_SYS)
//		sem_post(&m_ReqQryInvestorPositionDetail_signal);
//#endif // __WIN_SYS		
	}
}

void CUser::OnRspQryNotice(CThostFtdcNoticeField *pNotice, CThostFtdcRspInfoField *pRspInfo, int nRequestID, bool bIsLast)
{
	CTraderSpi::OnRspQryNotice(pNotice, pRspInfo, nRequestID, bIsLast);
	if (bIsLast)
	{
//#ifdef __WIN_SYS
//		SetEvent(m_ReqQryNotice_signal);
//#elif defined(__UNIX_SYS)
//		sem_post(&m_ReqQryNotice_signal);
//#endif // __WIN_SYS		
	}
}

void CUser::OnRspQrySettlementInfoConfirm(CThostFtdcSettlementInfoConfirmField *pSettlementInfoConfirm, CThostFtdcRspInfoField *pRspInfo, int nRequestID, bool bIsLast)
{
	CTraderSpi::OnRspQrySettlementInfoConfirm(pSettlementInfoConfirm, pRspInfo, nRequestID, bIsLast);
	if (bIsLast)
	{
//#ifdef __WIN_SYS
//		SetEvent(m_ReqQrySettlementInfoConfirm_signal);
//#elif defined(__UNIX_SYS)
//		sem_post(&m_ReqQrySettlementInfoConfirm_signal);
//#endif // __WIN_SYS		
	}
}

void CUser::OnRspQryInvestorPositionCombineDetail(CThostFtdcInvestorPositionCombineDetailField *pInvestorPositionCombineDetail, CThostFtdcRspInfoField *pRspInfo, int nRequestID, bool bIsLast)
{
	CTraderSpi::OnRspQryInvestorPositionCombineDetail(pInvestorPositionCombineDetail, pRspInfo, nRequestID, bIsLast);
	if (bIsLast)
	{
//#ifdef __WIN_SYS
//		SetEvent(m_ReqQryInvestorPositionCombineDetail_signal);
//#elif defined(__UNIX_SYS)
//		sem_post(&m_ReqQryInvestorPositionCombineDetail_signal);
//#endif // __WIN_SYS		
	}
}

void CUser::OnRspQryCFMMCTradingAccountKey(CThostFtdcCFMMCTradingAccountKeyField *pCFMMCTradingAccountKey, CThostFtdcRspInfoField *pRspInfo, int nRequestID, bool bIsLast)
{
	CTraderSpi::OnRspQryCFMMCTradingAccountKey(pCFMMCTradingAccountKey, pRspInfo, nRequestID, bIsLast);
	if (bIsLast)
	{
//#ifdef __WIN_SYS
//		SetEvent(m_ReqQryCFMMCTradingAccountKey_signal);
//#elif defined(__UNIX_SYS)
//		sem_post(&m_ReqQryCFMMCTradingAccountKey_signal);
//#endif // __WIN_SYS		
	}
}

void CUser::OnRspQryEWarrantOffset(CThostFtdcEWarrantOffsetField *pEWarrantOffset, CThostFtdcRspInfoField *pRspInfo, int nRequestID, bool bIsLast)
{
	CTraderSpi::OnRspQryEWarrantOffset(pEWarrantOffset, pRspInfo, nRequestID, bIsLast);
	if (bIsLast)
	{
//#ifdef __WIN_SYS
//		SetEvent(m_ReqQryEWarrantOffset_signal);
//#elif defined(__UNIX_SYS)
//		sem_post(&m_ReqQryEWarrantOffset_signal);
//#endif // __WIN_SYS		
	}
}

void CUser::OnRspQryInvestorProductGroupMargin(CThostFtdcInvestorProductGroupMarginField *pInvestorProductGroupMargin, CThostFtdcRspInfoField *pRspInfo, int nRequestID, bool bIsLast)
{
	CTraderSpi::OnRspQryInvestorProductGroupMargin(pInvestorProductGroupMargin, pRspInfo, nRequestID, bIsLast);
	if (bIsLast)
	{
//#ifdef __WIN_SYS
//		SetEvent(m_ReqQryInvestorProductGroupMargin_signal);
//#elif defined(__UNIX_SYS)
//		sem_post(&m_ReqQryInvestorProductGroupMargin_signal);
//#endif // __WIN_SYS		
	}
}

void CUser::OnRspQryExchangeMarginRate(CThostFtdcExchangeMarginRateField *pExchangeMarginRate, CThostFtdcRspInfoField *pRspInfo, int nRequestID, bool bIsLast)
{
	CTraderSpi::OnRspQryExchangeMarginRate(pExchangeMarginRate, pRspInfo, nRequestID, bIsLast);
	if (bIsLast)
	{
//#ifdef __WIN_SYS
//		SetEvent(m_ReqQryExchangeMarginRate_signal);
//#elif defined(__UNIX_SYS)
//		sem_post(&m_ReqQryExchangeMarginRate_signal);
//#endif // __WIN_SYS		
	}
}

void CUser::OnRspQryExchangeMarginRateAdjust(CThostFtdcExchangeMarginRateAdjustField *pExchangeMarginRateAdjust, CThostFtdcRspInfoField *pRspInfo, int nRequestID, bool bIsLast)
{
	CTraderSpi::OnRspQryExchangeMarginRateAdjust(pExchangeMarginRateAdjust, pRspInfo, nRequestID, bIsLast);
	if (bIsLast)
	{
//#ifdef __WIN_SYS
//		SetEvent(m_ReqQryExchangeMarginRateAdjust_signal);
//#elif defined(__UNIX_SYS)
//		sem_post(&m_ReqQryExchangeMarginRateAdjust_signal);
//#endif // __WIN_SYS		
	}
}

void CUser::OnRspQryExchangeRate(CThostFtdcExchangeRateField *pExchangeRate, CThostFtdcRspInfoField *pRspInfo, int nRequestID, bool bIsLast)
{
	CTraderSpi::OnRspQryExchangeRate(pExchangeRate, pRspInfo, nRequestID, bIsLast);
	if (bIsLast)
	{
//#ifdef __WIN_SYS
//		SetEvent(m_ReqQryExchangeRate_signal);
//#elif defined(__UNIX_SYS)
//		sem_post(&m_ReqQryExchangeRate_signal);
//#endif // __WIN_SYS		
	}
}

void CUser::OnRspQrySecAgentACIDMap(CThostFtdcSecAgentACIDMapField *pSecAgentACIDMap, CThostFtdcRspInfoField *pRspInfo, int nRequestID, bool bIsLast)
{
	CTraderSpi::OnRspQrySecAgentACIDMap(pSecAgentACIDMap, pRspInfo, nRequestID, bIsLast);
	if (bIsLast)
	{
//#ifdef __WIN_SYS
//		SetEvent(m_ReqQrySecAgentACIDMap_signal);
//#elif defined(__UNIX_SYS)
//		sem_post(&m_ReqQrySecAgentACIDMap_signal);
//#endif // __WIN_SYS		
	}
}

void CUser::OnRspQryProductExchRate(CThostFtdcProductExchRateField *pProductExchRate, CThostFtdcRspInfoField *pRspInfo, int nRequestID, bool bIsLast)
{
	CTraderSpi::OnRspQryProductExchRate(pProductExchRate, pRspInfo, nRequestID, bIsLast);
	if (bIsLast)
	{
//#ifdef __WIN_SYS
//		SetEvent(m_ReqQryProductExchRate_signal);
//#elif defined(__UNIX_SYS)
//		sem_post(&m_ReqQryProductExchRate_signal);
//#endif // __WIN_SYS		
	}
}

void CUser::OnRspQryProductGroup(CThostFtdcProductGroupField *pProductGroup, CThostFtdcRspInfoField *pRspInfo, int nRequestID, bool bIsLast)
{
	CTraderSpi::OnRspQryProductGroup(pProductGroup, pRspInfo, nRequestID, bIsLast);
	if (bIsLast)
	{
//#ifdef __WIN_SYS
//		SetEvent(m_ReqQryProductGroup_signal);
//#elif defined(__UNIX_SYS)
//		sem_post(&m_ReqQryProductGroup_signal);
//#endif // __WIN_SYS		
	}
}

void CUser::OnRspQryMMInstrumentCommissionRate(CThostFtdcMMInstrumentCommissionRateField *pMMInstrumentCommissionRate, CThostFtdcRspInfoField *pRspInfo, int nRequestID, bool bIsLast)
{
	CTraderSpi::OnRspQryMMInstrumentCommissionRate(pMMInstrumentCommissionRate, pRspInfo, nRequestID, bIsLast);
	if (bIsLast)
	{
//#ifdef __WIN_SYS
//		SetEvent(m_ReqQryMMInstrumentCommissionRate_signal);
//#elif defined(__UNIX_SYS)
//		sem_post(&m_ReqQryMMInstrumentCommissionRate_signal);
//#endif // __WIN_SYS		
	}
}

void CUser::OnRspQryMMOptionInstrCommRate(CThostFtdcMMOptionInstrCommRateField *pMMOptionInstrCommRate, CThostFtdcRspInfoField *pRspInfo, int nRequestID, bool bIsLast)
{
	CTraderSpi::OnRspQryMMOptionInstrCommRate(pMMOptionInstrCommRate, pRspInfo, nRequestID, bIsLast);
	if (bIsLast)
	{
//#ifdef __WIN_SYS
//		SetEvent(m_ReqQryMMOptionInstrCommRate_signal);
//#elif defined(__UNIX_SYS)
//		sem_post(&m_ReqQryMMOptionInstrCommRate_signal);
//#endif // __WIN_SYS		
	}
}

void CUser::OnRspQryInstrumentOrderCommRate(CThostFtdcInstrumentOrderCommRateField *pInstrumentOrderCommRate, CThostFtdcRspInfoField *pRspInfo, int nRequestID, bool bIsLast)
{
	CTraderSpi::OnRspQryInstrumentOrderCommRate(pInstrumentOrderCommRate, pRspInfo, nRequestID, bIsLast);
	if (bIsLast)
	{
//#ifdef __WIN_SYS
//		SetEvent(m_ReqQryInstrumentOrderCommRate_signal);
//#elif defined(__UNIX_SYS)
//		sem_post(&m_ReqQryInstrumentOrderCommRate_signal);
//#endif // __WIN_SYS		
	}
}

void CUser::OnRspQryOptionInstrTradeCost(CThostFtdcOptionInstrTradeCostField *pOptionInstrTradeCost, CThostFtdcRspInfoField *pRspInfo, int nRequestID, bool bIsLast)
{
	CTraderSpi::OnRspQryOptionInstrTradeCost(pOptionInstrTradeCost, pRspInfo, nRequestID, bIsLast);
	if (bIsLast)
	{
//#ifdef __WIN_SYS
//		SetEvent(m_ReqQryOptionInstrTradeCost_signal);
//#elif defined(__UNIX_SYS)
//		sem_post(&m_ReqQryOptionInstrTradeCost_signal);
//#endif // __WIN_SYS		
	}
}

void CUser::OnRspQryOptionInstrCommRate(CThostFtdcOptionInstrCommRateField *pOptionInstrCommRate, CThostFtdcRspInfoField *pRspInfo, int nRequestID, bool bIsLast)
{
	CTraderSpi::OnRspQryOptionInstrCommRate(pOptionInstrCommRate, pRspInfo, nRequestID, bIsLast);
	if (bIsLast)
	{
//#ifdef __WIN_SYS
//		SetEvent(m_ReqQryOptionInstrCommRate_signal);
//#elif defined(__UNIX_SYS)
//		sem_post(&m_ReqQryOptionInstrCommRate_signal);
//#endif // __WIN_SYS		
	}
}

void CUser::OnRspQryExecOrder(CThostFtdcExecOrderField *pExecOrder, CThostFtdcRspInfoField *pRspInfo, int nRequestID, bool bIsLast)
{
	CTraderSpi::OnRspQryExecOrder(pExecOrder, pRspInfo, nRequestID, bIsLast);
	if (bIsLast)
	{
//#ifdef __WIN_SYS
//		SetEvent(m_ReqQryExecOrder_signal);
//#elif defined(__UNIX_SYS)
//		sem_post(&m_ReqQryExecOrder_signal);
//#endif // __WIN_SYS		
	}
}

void CUser::OnRspQryForQuote(CThostFtdcForQuoteField *pForQuote, CThostFtdcRspInfoField *pRspInfo, int nRequestID, bool bIsLast)
{
	CTraderSpi::OnRspQryForQuote(pForQuote, pRspInfo, nRequestID, bIsLast);
	if (bIsLast)
	{
//#ifdef __WIN_SYS
//		SetEvent(m_ReqQryForQuote_signal);
//#elif defined(__UNIX_SYS)
//		sem_post(&m_ReqQryForQuote_signal);
//#endif // __WIN_SYS		
	}
}

void CUser::OnRspQryQuote(CThostFtdcQuoteField *pQuote, CThostFtdcRspInfoField *pRspInfo, int nRequestID, bool bIsLast)
{
	CTraderSpi::OnRspQryQuote(pQuote, pRspInfo, nRequestID, bIsLast);
	if (bIsLast)
	{
//#ifdef __WIN_SYS
//		SetEvent(m_ReqQryQuote_signal);
//#elif defined(__UNIX_SYS)
//		sem_post(&m_ReqQryQuote_signal);
//#endif // __WIN_SYS		
	}
}

void CUser::OnRspQryLock(CThostFtdcLockField *pLock, CThostFtdcRspInfoField *pRspInfo, int nRequestID, bool bIsLast)
{
	CTraderSpi::OnRspQryLock(pLock, pRspInfo, nRequestID, bIsLast);
	if (bIsLast)
	{
//#ifdef __WIN_SYS
//		SetEvent(m_ReqQryLock_signal);
//#elif defined(__UNIX_SYS)
//		sem_post(&m_ReqQryLock_signal);
//#endif // __WIN_SYS		
	}
}

void CUser::OnRspQryLockPosition(CThostFtdcLockPositionField *pLockPosition, CThostFtdcRspInfoField *pRspInfo, int nRequestID, bool bIsLast)
{
	CTraderSpi::OnRspQryLockPosition(pLockPosition, pRspInfo, nRequestID, bIsLast);
	if (bIsLast)
	{
//#ifdef __WIN_SYS
//		SetEvent(m_ReqQryLockPosition_signal);
//#elif defined(__UNIX_SYS)
//		sem_post(&m_ReqQryLockPosition_signal);
//#endif // __WIN_SYS		
	}
}

void CUser::OnRspQryETFOptionInstrCommRate(CThostFtdcETFOptionInstrCommRateField *pETFOptionInstrCommRate, CThostFtdcRspInfoField *pRspInfo, int nRequestID, bool bIsLast)
{
	CTraderSpi::OnRspQryETFOptionInstrCommRate(pETFOptionInstrCommRate, pRspInfo, nRequestID, bIsLast);
	if (bIsLast)
	{
//#ifdef __WIN_SYS
//		SetEvent(m_ReqQryETFOptionInstrCommRate_signal);
//#elif defined(__UNIX_SYS)
//		sem_post(&m_ReqQryETFOptionInstrCommRate_signal);
//#endif // __WIN_SYS		
	}
}

void CUser::OnRspQryInvestorLevel(CThostFtdcInvestorLevelField *pInvestorLevel, CThostFtdcRspInfoField *pRspInfo, int nRequestID, bool bIsLast)
{
	CTraderSpi::OnRspQryInvestorLevel(pInvestorLevel, pRspInfo, nRequestID, bIsLast);
	if (bIsLast)
	{
//#ifdef __WIN_SYS
//		SetEvent(m_ReqQryInvestorLevel_signal);
//#elif defined(__UNIX_SYS)
//		sem_post(&m_ReqQryInvestorLevel_signal);
//#endif // __WIN_SYS		
	}
}

void CUser::OnRspQryExecFreeze(CThostFtdcExecFreezeField *pExecFreeze, CThostFtdcRspInfoField *pRspInfo, int nRequestID, bool bIsLast)
{
	CTraderSpi::OnRspQryExecFreeze(pExecFreeze, pRspInfo, nRequestID, bIsLast);
	if (bIsLast)
	{
//#ifdef __WIN_SYS
//		SetEvent(m_ReqQryInvestorLevel_signal);
//#elif defined(__UNIX_SYS)
//		sem_post(&m_ReqQryInvestorLevel_signal);
//#endif // __WIN_SYS		
	}
}

void CUser::OnRspQryCombInstrumentGuard(CThostFtdcCombInstrumentGuardField *pCombInstrumentGuard, CThostFtdcRspInfoField *pRspInfo, int nRequestID, bool bIsLast)
{
	CTraderSpi::OnRspQryCombInstrumentGuard(pCombInstrumentGuard, pRspInfo, nRequestID, bIsLast);
	if (bIsLast)
	{
//#ifdef __WIN_SYS
//		SetEvent(m_ReqQryCombInstrumentGuard_signal);
//#elif defined(__UNIX_SYS)
//		sem_post(&m_ReqQryCombInstrumentGuard_signal);
//#endif // __WIN_SYS		
	}
}

void CUser::OnRspQryCombAction(CThostFtdcCombActionField *pCombAction, CThostFtdcRspInfoField *pRspInfo, int nRequestID, bool bIsLast)
{
	CTraderSpi::OnRspQryCombAction(pCombAction, pRspInfo, nRequestID, bIsLast);
	if (bIsLast)
	{
//#ifdef __WIN_SYS
//		SetEvent(m_ReqQryCombAction_signal);
//#elif defined(__UNIX_SYS)
//		sem_post(&m_ReqQryCombAction_signal);
//#endif // __WIN_SYS		
	}
}

void CUser::OnRspQryTransferSerial(CThostFtdcTransferSerialField *pTransferSerial, CThostFtdcRspInfoField *pRspInfo, int nRequestID, bool bIsLast)
{
	CTraderSpi::OnRspQryTransferSerial(pTransferSerial, pRspInfo, nRequestID, bIsLast);
	if (bIsLast)
	{
//#ifdef __WIN_SYS
//		SetEvent(m_ReqQryTransferSerial_signal);
//#elif defined(__UNIX_SYS)
//  	sem_post(&m_ReqQryTransferSerial_signal);
//#endif // __WIN_SYS		
	}
}

void CUser::OnRspQryAccountregister(CThostFtdcAccountregisterField *pAccountregister, CThostFtdcRspInfoField *pRspInfo, int nRequestID, bool bIsLast)
{
	CTraderSpi::OnRspQryAccountregister(pAccountregister, pRspInfo, nRequestID, bIsLast);
	if (bIsLast)
	{
//#ifdef __WIN_SYS
//		SetEvent(m_ReqQryAccountregister_signal);
//#elif defined(__UNIX_SYS)
//		sem_post(&m_ReqQryAccountregister_signal);
//#endif // __WIN_SYS		
	}
}

void CUser::OnRspError(CThostFtdcRspInfoField *pRspInfo, int nRequestID, bool bIsLast)
{
	CTraderSpi::OnRspError(pRspInfo, nRequestID, bIsLast);
}

void CUser::OnRtnOrder(CThostFtdcOrderField *pOrder)
{
	CTraderSpi::OnRtnOrder(pOrder);
}

void CUser::OnRtnTrade(CThostFtdcTradeField *pTrade)
{
	CTraderSpi::OnRtnTrade(pTrade);
}

void CUser::OnErrRtnOrderInsert(CThostFtdcInputOrderField *pInputOrder, CThostFtdcRspInfoField *pRspInfo)
{
	CTraderSpi::OnErrRtnOrderInsert(pInputOrder, pRspInfo);
}

void CUser::OnErrRtnOrderAction(CThostFtdcOrderActionField *pOrderAction, CThostFtdcRspInfoField *pRspInfo)
{
	CTraderSpi::OnErrRtnOrderAction(pOrderAction, pRspInfo);
}

void CUser::OnRtnInstrumentStatus(CThostFtdcInstrumentStatusField *pInstrumentStatus)
{
	//CTraderSpi::OnRtnInstrumentStatus(pInstrumentStatus);
}

void CUser::OnRtnBulletin(CThostFtdcBulletinField *pBulletin)
{
	CTraderSpi::OnRtnBulletin(pBulletin);
}

void CUser::OnRtnTradingNotice(CThostFtdcTradingNoticeInfoField *pTradingNoticeInfo)
{
	CTraderSpi::OnRtnTradingNotice(pTradingNoticeInfo);
}

void CUser::OnRtnErrorConditionalOrder(CThostFtdcErrorConditionalOrderField *pErrorConditionalOrder)
{
	CTraderSpi::OnRtnErrorConditionalOrder(pErrorConditionalOrder);
}

void CUser::OnRtnExecOrder(CThostFtdcExecOrderField *pExecOrder)
{
	CTraderSpi::OnRtnExecOrder(pExecOrder);
}
void CUser::OnErrRtnExecOrderInsert(CThostFtdcInputExecOrderField *pInputExecOrder, CThostFtdcRspInfoField *pRspInfo)
{
	CTraderSpi::OnErrRtnExecOrderInsert(pInputExecOrder, pRspInfo);
}

void CUser::OnErrRtnExecOrderAction(CThostFtdcExecOrderActionField *pExecOrderAction, CThostFtdcRspInfoField *pRspInfo)
{
	CTraderSpi::OnErrRtnExecOrderAction(pExecOrderAction, pRspInfo);
}

void CUser::OnErrRtnForQuoteInsert(CThostFtdcInputForQuoteField *pInputForQuote, CThostFtdcRspInfoField *pRspInfo)
{
	CTraderSpi::OnErrRtnForQuoteInsert(pInputForQuote, pRspInfo);
}

void CUser::OnRtnQuote(CThostFtdcQuoteField *pQuote)
{
	CTraderSpi::OnRtnQuote(pQuote);
}

void CUser::OnErrRtnQuoteInsert(CThostFtdcInputQuoteField *pInputQuote, CThostFtdcRspInfoField *pRspInfo)
{
	CTraderSpi::OnErrRtnQuoteInsert(pInputQuote, pRspInfo);
}

void CUser::OnErrRtnQuoteAction(CThostFtdcQuoteActionField *pQuoteAction, CThostFtdcRspInfoField *pRspInfo)
{
	CTraderSpi::OnErrRtnQuoteAction(pQuoteAction, pRspInfo);
}

void CUser::OnRtnForQuoteRsp(CThostFtdcForQuoteRspField *pForQuoteRsp)
{
	CTraderSpi::OnRtnForQuoteRsp(pForQuoteRsp);
}

void CUser::OnRtnCFMMCTradingAccountToken(CThostFtdcCFMMCTradingAccountTokenField *pCFMMCTradingAccountToken)
{
	CTraderSpi::OnRtnCFMMCTradingAccountToken(pCFMMCTradingAccountToken);
}

void CUser::OnRtnLock(CThostFtdcLockField *pLock)
{
	CTraderSpi::OnRtnLock(pLock);
}

void CUser::OnErrRtnLockInsert(CThostFtdcInputLockField *pInputLock, CThostFtdcRspInfoField *pRspInfo)
{
	CTraderSpi::OnErrRtnLockInsert(pInputLock, pRspInfo);
}

void CUser::OnErrRtnBatchOrderAction(CThostFtdcBatchOrderActionField *pBatchOrderAction, CThostFtdcRspInfoField *pRspInfo)
{
	CTraderSpi::OnErrRtnBatchOrderAction(pBatchOrderAction, pRspInfo);
}

void CUser::OnRtnCombAction(CThostFtdcCombActionField *pCombAction)
{
	CTraderSpi::OnRtnCombAction(pCombAction);
}

void CUser::OnErrRtnCombActionInsert(CThostFtdcInputCombActionField *pInputCombAction, CThostFtdcRspInfoField *pRspInfo)
{
	CTraderSpi::OnErrRtnCombActionInsert(pInputCombAction, pRspInfo);
}

void CUser::OnRspQryContractBank(CThostFtdcContractBankField *pContractBank, CThostFtdcRspInfoField *pRspInfo, int nRequestID, bool bIsLast)
{
	CTraderSpi::OnRspQryContractBank(pContractBank, pRspInfo, nRequestID, bIsLast);
}
void CUser::OnRspQryParkedOrder(CThostFtdcParkedOrderField *pParkedOrder, CThostFtdcRspInfoField *pRspInfo, int nRequestID, bool bIsLast)
{

}
void CUser::OnRspQryParkedOrderAction(CThostFtdcParkedOrderActionField *pParkedOrderAction, CThostFtdcRspInfoField *pRspInfo, int nRequestID, bool bIsLast)
{

}
void CUser::OnRspQryTradingNotice(CThostFtdcTradingNoticeField *pTradingNotice, CThostFtdcRspInfoField *pRspInfo, int nRequestID, bool bIsLast)
{
	CTraderSpi::OnRspQryTradingNotice(pTradingNotice, pRspInfo, nRequestID, bIsLast);
}
void CUser::OnRspQryBrokerTradingParams(CThostFtdcBrokerTradingParamsField *pBrokerTradingParams, CThostFtdcRspInfoField *pRspInfo, int nRequestID, bool bIsLast)
{
	CTraderSpi::OnRspQryBrokerTradingParams(pBrokerTradingParams, pRspInfo, nRequestID, bIsLast);
}
void CUser::OnRspQryBrokerTradingAlgos(CThostFtdcBrokerTradingAlgosField *pBrokerTradingAlgos, CThostFtdcRspInfoField *pRspInfo, int nRequestID, bool bIsLast)
{
	CTraderSpi::OnRspQryBrokerTradingAlgos(pBrokerTradingAlgos, pRspInfo, nRequestID, bIsLast);
}
void CUser::OnRspQueryCFMMCTradingAccountToken(CThostFtdcQueryCFMMCTradingAccountTokenField *pQueryCFMMCTradingAccountToken, CThostFtdcRspInfoField *pRspInfo, int nRequestID, bool bIsLast)
{

}
void CUser::OnRtnFromBankToFutureByBank(CThostFtdcRspTransferField *pRspTransfer)
{

}
void CUser::OnRtnFromFutureToBankByBank(CThostFtdcRspTransferField *pRspTransfer)
{

}
void CUser::OnRtnRepealFromBankToFutureByBank(CThostFtdcRspRepealField *pRspRepeal)
{

}
void CUser::OnRtnRepealFromFutureToBankByBank(CThostFtdcRspRepealField *pRspRepeal)
{

}
void CUser::OnRtnFromBankToFutureByFuture(CThostFtdcRspTransferField *pRspTransfer)
{

}
void CUser::OnRtnFromFutureToBankByFuture(CThostFtdcRspTransferField *pRspTransfer)
{

}
void CUser::OnRtnRepealFromBankToFutureByFutureManual(CThostFtdcRspRepealField *pRspRepeal)
{

}
void CUser::OnRtnRepealFromFutureToBankByFutureManual(CThostFtdcRspRepealField *pRspRepeal)
{

}
void CUser::OnRtnQueryBankBalanceByFuture(CThostFtdcNotifyQueryAccountField *pNotifyQueryAccount)
{
	
}
void CUser::OnErrRtnBankToFutureByFuture(CThostFtdcReqTransferField *pReqTransfer, CThostFtdcRspInfoField *pRspInfo)
{

}
void CUser::OnErrRtnFutureToBankByFuture(CThostFtdcReqTransferField *pReqTransfer, CThostFtdcRspInfoField *pRspInfo)
{

}
void CUser::OnErrRtnRepealBankToFutureByFutureManual(CThostFtdcReqRepealField *pReqRepeal, CThostFtdcRspInfoField *pRspInfo)
{

}
void CUser::OnErrRtnRepealFutureToBankByFutureManual(CThostFtdcReqRepealField *pReqRepeal, CThostFtdcRspInfoField *pRspInfo)
{

}

void CUser::OnRspQryLimitPosi(CThostFtdcLimitPosiField * pLimitPosi, CThostFtdcRspInfoField * pRspInfo, int nRequestID, bool bIsLast)
{
	CTraderSpi::OnRspQryLimitPosi(pLimitPosi, pRspInfo, nRequestID, bIsLast);
}

void CUser::OnRspQryLimitAmount(CThostFtdcLimitAmountField * pLimitAmount, CThostFtdcRspInfoField * pRspInfo, int nRequestID, bool bIsLast)
{
	CTraderSpi::OnRspQryLimitAmount(pLimitAmount, pRspInfo, nRequestID, bIsLast);
}

void CUser::OnRspInternalTransfer(CThostFtdcInputInternalTransferField * pInputInternalTransfer, CThostFtdcRspInfoField * pRspInfo, int nRequestID, bool bIsLast)
{
	CTraderSpi::OnRspInternalTransfer(pInputInternalTransfer, pRspInfo, nRequestID, bIsLast);
}

void CUser::OnRtnInternalTransfer(CThostFtdcRtnInternalTransferField * pRtnInternalTransfer)
{
	CTraderSpi::OnRtnInternalTransfer(pRtnInternalTransfer);
}

