#ifndef MDHANDLE_H
#define MDHANDLE_H

#include "define.h"
#include "getconfig.h"
#include "ThostFtdcMdApi.h"
#include <iostream>

#ifdef __WIN_SYS
#include <Windows.h>
#elif defined(__UNIX_SYS)
#include <semaphore.h>
#endif 


class CMdUser : public CThostFtdcMdSpi
{
public:
	CMdUser();
	~CMdUser();

public:
	void Init();
	void Release();
	void Join();
	void ReqUserLogin();
	void ReqUserLogout();
	void SubscribeMarketData();
	void UnSubscribeMarketData();
	void SubscribeForQuoteRsp();
	void UnSubscribeForQuoteRsp();

	virtual void OnFrontConnected();
	virtual void OnFrontDisconnected(int nReason);
	virtual void OnHeartBeatWarning(int nTimeLapse);
	virtual void OnRspUserLogin(CThostFtdcRspUserLoginField *pRspUserLogin, CThostFtdcRspInfoField *pRspInfo, int nRequestID, bool bIsLast);
	virtual void OnRspUserLogout(CThostFtdcUserLogoutField *pUserLogout, CThostFtdcRspInfoField *pRspInfo, int nRequestID, bool bIsLast);
	virtual void OnRspError(CThostFtdcRspInfoField *pRspInfo, int nRequestID, bool bIsLast);
	virtual void OnRspSubMarketData(CThostFtdcSpecificInstrumentField *pSpecificInstrument, CThostFtdcRspInfoField *pRspInfo, int nRequestID, bool bIsLast);
	virtual void OnRspUnSubMarketData(CThostFtdcSpecificInstrumentField *pSpecificInstrument, CThostFtdcRspInfoField *pRspInfo, int nRequestID, bool bIsLast);
	virtual void OnRspSubForQuoteRsp(CThostFtdcSpecificInstrumentField *pSpecificInstrument, CThostFtdcRspInfoField *pRspInfo, int nRequestID, bool bIsLast);
	virtual void OnRspUnSubForQuoteRsp(CThostFtdcSpecificInstrumentField *pSpecificInstrument, CThostFtdcRspInfoField *pRspInfo, int nRequestID, bool bIsLast);
	virtual void OnRtnDepthMarketData(CThostFtdcDepthMarketDataField *pDepthMarketData);
	virtual void OnRtnForQuoteRsp(CThostFtdcForQuoteRspField *pForQuoteRsp);


private:
	CThostFtdcMdApi *m_pMdapi;
	string m_FrontMdAddr;
	string m_InstrumentID;

#ifdef __WIN_SYS
	HANDLE m_md_Release_signal;
	HANDLE m_md_Init_signal;
	HANDLE m_md_Join_signal;
	HANDLE m_md_ReqUserLogin_signal;
	HANDLE m_md_ReqUserLogout_signal;
	HANDLE m_md_SubscribeMarketData_signal;
	HANDLE m_md_UnSubscribeMarketData_signal;
	HANDLE m_md_SubscribeForQuoteRsp_signal;
	HANDLE m_md_UnSubscribeForQuoteRsp_signal;

#elif defined(__UNIX_SYS)
	sem_t m_md_Release_signal;
	sem_t m_md_Init_signal;
	sem_t m_md_Join_signal;
	sem_t m_md_ReqUserLogin_signal;
	sem_t m_md_ReqUserLogout_signal;
	sem_t m_md_SubscribeMarketData_signal;
	sem_t m_md_UnSubscribeMarketData_signal;
	sem_t m_md_SubscribeForQuoteRsp_signal;
	sem_t m_md_UnSubscribeForQuoteRsp_signal;
#endif

};

#endif // !MDHANDLE_H
