#include "mdhandle.h"


CMdUser::CMdUser()
{
	m_FrontMdAddr = getConfig("config", "FrontMdAddr");
	m_InstrumentID = getConfig("config", "InstrumentID");

#ifdef __WIN_SYS
	m_md_Release_signal = CreateEvent(NULL, false, false, NULL);
	m_md_Init_signal = CreateEvent(NULL, false, false, NULL);
	m_md_Join_signal = CreateEvent(NULL, false, false, NULL);
	m_md_ReqUserLogin_signal = CreateEvent(NULL, false, false, NULL);
	m_md_ReqUserLogout_signal = CreateEvent(NULL, false, false, NULL);
	m_md_SubscribeMarketData_signal = CreateEvent(NULL, false, false, NULL);
	m_md_UnSubscribeMarketData_signal = CreateEvent(NULL, false, false, NULL);
	m_md_SubscribeForQuoteRsp_signal = CreateEvent(NULL, false, false, NULL);
	m_md_UnSubscribeForQuoteRsp_signal = CreateEvent(NULL, false, false, NULL);
#elif defined(__UNIX_SYS)
	sem_init(&m_md_Release_signal, 0, 0);
	sem_init(&m_md_Init_signal, 0, 0);
	sem_init(&m_md_Join_signal, 0, 0);
	sem_init(&m_md_ReqUserLogin_signal, 0, 0);
	sem_init(&m_md_ReqUserLogout_signal, 0, 0);
	sem_init(&m_md_SubscribeMarketData_signal, 0, 0);
	sem_init(&m_md_UnSubscribeMarketData_signal, 0, 0);
	sem_init(&m_md_SubscribeForQuoteRsp_signal, 0, 0);
	sem_init(&m_md_UnSubscribeForQuoteRsp_signal, 0, 0);
#endif
}

CMdUser::~CMdUser()
{

}

void CMdUser::Init()
{
	m_pMdapi = CThostFtdcMdApi::CreateFtdcMdApi("/md_flow");
	LOG("<RegisterSpi>\n");
	LOG("</RegisterSpi>\n");
	m_pMdapi->RegisterSpi(this);
	LOG("<RegisterFront>\n");
	LOG("\tpszFrontAddress [%s]\n", const_cast<char *>(m_FrontMdAddr.c_str()));
	LOG("</RegisterFront>\n");
	m_pMdapi->RegisterFront(const_cast<char *>(m_FrontMdAddr.c_str()));
	LOG("<Init>\n");
	LOG("</Init>\n")
	m_pMdapi->Init();

#ifdef __WIN_SYS
	WaitForSingleObject(m_md_Init_signal, INFINITE);
#elif defined(__UNIX_SYS)
	sem_wait(&m_md_Init_signal);
#endif // 
}

void CMdUser::Release()
{
	LOG("<Release>\n");
	LOG("</Release>\n");

	m_pMdapi->Release();
}

void CMdUser::Join()
{
	LOG("<Join>\n");
	LOG("</Join>\n");

	m_pMdapi->Join();
}

void CMdUser::ReqUserLogin()
{
	CThostFtdcReqUserLoginField pReqUserLoginField;
	memset(&pReqUserLoginField, 0, sizeof(CThostFtdcReqUserLoginField));	

	LOG("<ReqUserLogin>\n");
	LOG("\tTradingDay [%s]\n", pReqUserLoginField.TradingDay);
	LOG("\tBrokerID [%s]\n", pReqUserLoginField.BrokerID);
	LOG("\tUserID [%s]\n", pReqUserLoginField.UserID);
	LOG("\tPassword [%s]\n", pReqUserLoginField.Password);
	LOG("\tUserProductInfo [%s]\n", pReqUserLoginField.UserProductInfo);
	LOG("\tInterfaceProductInfo [%s]\n", pReqUserLoginField.InterfaceProductInfo);
	LOG("\tProtocolInfo [%s]\n", pReqUserLoginField.ProtocolInfo);
	LOG("\tMacAddress [%s]\n", pReqUserLoginField.MacAddress);
	LOG("\tOneTimePassword [%s]\n", pReqUserLoginField.OneTimePassword);
	LOG("\tClientIPAddress [%s]\n", pReqUserLoginField.ClientIPAddress);
	LOG("\tLoginRemark [%s]\n", pReqUserLoginField.LoginRemark);
	LOG("\tClientIPPort [%d]\n", pReqUserLoginField.ClientIPPort);
	LOG("</ReqUserLogin>\n");

	int a = m_pMdapi->ReqUserLogin(&pReqUserLoginField, 1);
	LOG((a == 0) ? "�û���¼����......���ͳɹ�[%d]\n" : "�û���¼����......����ʧ�ܣ��������=[%d]\n", a);

#ifdef __WIN_SYS
	WaitForSingleObject(m_md_ReqUserLogin_signal, INFINITE);
#elif defined(__UNIX_SYS)
	sem_wait(&m_md_Im_md_ReqUserLogin_signalnit_signal);
#endif // 

}

void CMdUser::ReqUserLogout()
{
	CThostFtdcUserLogoutField pUserLogout;
	memset(&pUserLogout, 0, sizeof(CThostFtdcUserLogoutField));

	LOG("<ReqUserLogout>\n");
	LOG("\tBrokerID [%s]\n", pUserLogout.BrokerID);
	LOG("\tUserID [%s]\n", pUserLogout.UserID);
	LOG("</ReqUserLogout>\n");

	int a = m_pMdapi->ReqUserLogout(&pUserLogout, 1);
	LOG((a == 0) ? "�û��ǳ�����......���ͳɹ�[%d]\n" : "�û��ǳ�����......����ʧ�ܣ��������=[%d]\n", a);

#ifdef __WIN_SYS
	WaitForSingleObject(m_md_ReqUserLogout_signal, INFINITE);
#elif defined(__UNIX_SYS)
	sem_wait(&m_md_ReqUserLogout_signal);
#endif // __WIN_SYS
}

void CMdUser::SubscribeMarketData()
{
	//���ݶ��ĺ�Լ��������ppInstrumentID�������
	char **ppInstrumentID = new char*[100];
	ppInstrumentID[0] = (char*)m_InstrumentID.c_str();

	LOG("<SubscribeMarketData>\n");
	LOG("\tppInstrumentID [%s]\n", ppInstrumentID[0]);
	LOG("</SubscribeMarketData>\n");

	int a = m_pMdapi->SubscribeMarketData(&ppInstrumentID[0], 1);
	LOG((a == 0) ? "����������......���ͳɹ�[%d]\n" : "����������......����ʧ�ܣ��������=[%d]\n", a);
#ifdef __WIN_SYS
	WaitForSingleObject(m_md_SubscribeMarketData_signal, INFINITE);
#elif defined(__UNIX_SYS)
	sem_wait(&m_md_SubscribeMarketData_signal);
#endif // __WIN_SYS
}

void CMdUser::UnSubscribeMarketData()
{
	//�����˶���Լ��������ppInstrumentID�������
	char **ppInstrumentID = new char*[100];
	ppInstrumentID[0] = (char*)m_InstrumentID.c_str();

	LOG("<UnSubscribeMarketData>\n");
	LOG("\tppInstrumentID [%s]\n", ppInstrumentID[0]);
	LOG("</UnSubscribeMarketData>\n");

	int a = m_pMdapi->UnSubscribeMarketData(&ppInstrumentID[0], 1);
	LOG((a == 0) ? "�����˶�����......���ͳɹ�[%d]\n" : "�����˶�����......����ʧ�ܣ��������=[%d]\n", a);

#ifdef __WIN_SYS
	WaitForSingleObject(m_md_UnSubscribeMarketData_signal, INFINITE);
#elif defined(__UNIX_SYS)
	sem_wait(&m_md_UnSubscribeMarketData_signal);
#endif // __WIN_SYS
}

void CMdUser::SubscribeForQuoteRsp()
{
	//���ݶ���ѯ�ۺ�Լ��������ppInstrumentID�������
	char **ppInstrumentID = new char*[100];
	ppInstrumentID[0] = (char*)m_InstrumentID.c_str();

	LOG("<UnSubscribeMarketData>\n");
	LOG("\tppInstrumentID [%s]\n", ppInstrumentID[0]);
	LOG("</UnSubscribeMarketData>\n");

	int a = m_pMdapi->SubscribeForQuoteRsp(&ppInstrumentID[0], 1);
	LOG((a == 0) ? "������ѯ��......���ͳɹ�[%d]\n" : "������ѯ��......����ʧ�ܣ��������=[%d]\n", a);

#ifdef __WIN_SYS
	WaitForSingleObject(m_md_SubscribeForQuoteRsp_signal, INFINITE);
#elif defined(__UNIX_SYS)
	sem_wait(&m_md_SubscribeForQuoteRsp_signal);
#endif // __WIN_SYS
}

void CMdUser::UnSubscribeForQuoteRsp()
{
	//�����˶�ѯ�ۺ�Լ��������ppInstrumentID�������
	char **ppInstrumentID = new char*[100];
	ppInstrumentID[0] = (char*)m_InstrumentID.c_str();

	LOG("<UnSubscribeMarketData>\n");
	LOG("\tppInstrumentID [%s]\n", ppInstrumentID[0]);
	LOG("</UnSubscribeMarketData>\n");

	int a = m_pMdapi->UnSubscribeForQuoteRsp(&ppInstrumentID[0], 1);
	LOG((a == 0) ? "�����˶�ѯ��......���ͳɹ�[%d]\n" : "�����˶�ѯ��......����ʧ�ܣ��������=[%d]\n", a);

#ifdef __WIN_SYS
	WaitForSingleObject(m_md_UnSubscribeForQuoteRsp_signal, INFINITE);
#elif defined(__UNIX_SYS)
	sem_wait(&m_md_UnSubscribeForQuoteRsp_signal);
#endif // __WIN_SYS
}

void CMdUser::OnFrontConnected()
{
	LOG("<OnFrontConnected>\n");
	LOG("</OnFrontConnected>\n");
	

#ifdef __WIN_SYS
	SetEvent(m_md_Init_signal);
#elif defined(__UNIX_SYS)
	sem_post(&m_md_Init_signal);
#endif // __WIN_SYS
}

void CMdUser::OnFrontDisconnected(int nReason)
{
	LOG("<OnFrontDisconnected>\n");
	LOG("\tnReason [%d]\n", nReason);
	LOG("</OnFrontDisconnected>\n");
}

void CMdUser::OnHeartBeatWarning(int nTimeLapse)
{
	LOG("<OnHeartBeatWarning>\n");
	LOG("\tnTimeLapse [%d]\n", nTimeLapse);
	LOG("</OnHeartBeatWarning>\n");
}

void CMdUser::OnRspUserLogin(CThostFtdcRspUserLoginField * pRspUserLogin, CThostFtdcRspInfoField * pRspInfo, int nRequestID, bool bIsLast)
{
	LOG("<OnRspUserLogin>\n");
	if (pRspUserLogin)
	{
		LOG("\tTradingDay [%s]\n", pRspUserLogin->TradingDay);
		LOG("\tLoginTime [%s]\n", pRspUserLogin->LoginTime);
		LOG("\tBrokerID [%s]\n", pRspUserLogin->BrokerID);
		LOG("\tUserID [%s]\n", pRspUserLogin->UserID);
		LOG("\tSystemName [%s]\n", pRspUserLogin->SystemName);
		LOG("\tMaxOrderRef [%s]\n", pRspUserLogin->MaxOrderRef);
		LOG("\tSHFETime [%s]\n", pRspUserLogin->SHFETime);
		LOG("\tDCETime [%s]\n", pRspUserLogin->DCETime);
		LOG("\tCZCETime [%s]\n", pRspUserLogin->CZCETime);
		LOG("\tFFEXTime [%s]\n", pRspUserLogin->FFEXTime);
		LOG("\tINETime [%s]\n", pRspUserLogin->INETime);
		LOG("\tFrontID [%d]\n", pRspUserLogin->FrontID);
		LOG("\tSessionID [%d]\n", pRspUserLogin->SessionID);
	}
	if (pRspInfo)
	{
		LOG("\tErrorMsg [%s]\n", pRspInfo->ErrorMsg);
		LOG("\tErrorID [%d]\n", pRspInfo->ErrorID);
	}
	LOG("\tnRequestID [%d]\n", nRequestID);
	LOG("\tbIsLast [%d]\n", bIsLast);
	LOG("</OnRspUserLogin>\n");

	if (bIsLast)
	{
#ifdef __WIN_SYS
		SetEvent(m_md_ReqUserLogin_signal);
#elif defined(__UNIX_SYS)
		sem_post(&m_md_ReqUserLogin_signal);
#endif // __WIN_SYS
	}
}

void CMdUser::OnRspUserLogout(CThostFtdcUserLogoutField * pUserLogout, CThostFtdcRspInfoField * pRspInfo, int nRequestID, bool bIsLast)
{
	LOG("<OnRspUserLogout>\n");
	if (pUserLogout)
	{
		LOG("\tBrokerID [%s]\n", pUserLogout->BrokerID);
		LOG("\tUserID [%s]\n", pUserLogout->UserID);
	}
	if (pRspInfo)
	{
		LOG("\tErrorMsg [%s]\n", pRspInfo->ErrorMsg);
		LOG("\tErrorID [%d]\n", pRspInfo->ErrorID);
	}
	LOG("\tnRequestID [%d]\n", nRequestID);
	LOG("\tbIsLast [%d]\n", bIsLast);
	LOG("</OnRspUserLogout>\n");

	if (bIsLast)
	{
#ifdef __WIN_SYS
		SetEvent(m_md_ReqUserLogout_signal);
#elif defined(__UNIX_SYS)
		sem_post(&m_md_ReqUserLogout_signal);
#endif // __WIN_SYS
	}
}

void CMdUser::OnRspError(CThostFtdcRspInfoField * pRspInfo, int nRequestID, bool bIsLast)
{
	LOG("<OnRspError>\n");
	if (pRspInfo)
	{
		LOG("\tErrorMsg [%s]\n", pRspInfo->ErrorMsg);
		LOG("\tErrorID [%d]\n", pRspInfo->ErrorID);
	}
	LOG("\tnRequestID [%d]\n", nRequestID);
	LOG("\tbIsLast [%d]\n", bIsLast);
	LOG("</OnRspError>\n");
}

void CMdUser::OnRspSubMarketData(CThostFtdcSpecificInstrumentField * pSpecificInstrument, CThostFtdcRspInfoField * pRspInfo, int nRequestID, bool bIsLast)
{
	LOG("<OnRspSubMarketData>\n");
	if (pSpecificInstrument)
	{
		LOG("\tInstrumentID = [%s]\n", pSpecificInstrument->InstrumentID);
	}
	if (pRspInfo)
	{
		LOG("\tErrorMsg = [%s]\n", pRspInfo->ErrorMsg);
		LOG("\tErrorID = [%d]\n", pRspInfo->ErrorID);
	}
	LOG("\tnRequestID = [%d]\n", nRequestID);
	LOG("\tbIsLast = [%d]\n", bIsLast);
	LOG("</OnRspSubMarketData>\n");

	if (bIsLast)
	{
#ifdef __WIN_SYS
		SetEvent(m_md_SubscribeMarketData_signal);
#elif defined(__UNIX_SYS)
		sem_post(&m_md_SubscribeMarketData_signal);
#endif // __WIN_SYS
	}
}

void CMdUser::OnRspUnSubMarketData(CThostFtdcSpecificInstrumentField * pSpecificInstrument, CThostFtdcRspInfoField * pRspInfo, int nRequestID, bool bIsLast)
{
	LOG("<OnRspSubMarketData>\n");
	if (pSpecificInstrument)
	{
		LOG("\tInstrumentID = [%s]\n", pSpecificInstrument->InstrumentID);
	}
	if (pRspInfo)
	{
		LOG("\tErrorMsg = [%s]\n", pRspInfo->ErrorMsg);
		LOG("\tErrorID = [%d]\n", pRspInfo->ErrorID);
	}
	LOG("\tnRequestID = [%d]\n", nRequestID);
	LOG("\tbIsLast = [%d]\n", bIsLast);
	LOG("</OnRspSubMarketData>\n");

	if (bIsLast)
	{
#ifdef __WIN_SYS
		SetEvent(m_md_UnSubscribeMarketData_signal);
#elif defined(__UNIX_SYS)
		sem_post(&m_md_UnSubscribeMarketData_signal);
#endif // __WIN_SYS
	}
}

void CMdUser::OnRspSubForQuoteRsp(CThostFtdcSpecificInstrumentField * pSpecificInstrument, CThostFtdcRspInfoField * pRspInfo, int nRequestID, bool bIsLast)
{
	LOG("<OnRspSubMarketData>\n");
	if (pSpecificInstrument)
	{
		LOG("\tInstrumentID = [%s]\n", pSpecificInstrument->InstrumentID);
	}
	if (pRspInfo)
	{
		LOG("\tErrorMsg = [%s]\n", pRspInfo->ErrorMsg);
		LOG("\tErrorID = [%d]\n", pRspInfo->ErrorID);
	}
	LOG("\tnRequestID = [%d]\n", nRequestID);
	LOG("\tbIsLast = [%d]\n", bIsLast);
	LOG("</OnRspSubMarketData>\n");

	if (bIsLast)
	{
#ifdef __WIN_SYS
		SetEvent(m_md_SubscribeForQuoteRsp_signal);
#elif defined(__UNIX_SYS)
		sem_post(&m_md_SubscribeForQuoteRsp_signal);
#endif // __WIN_SYS
	}
}

void CMdUser::OnRspUnSubForQuoteRsp(CThostFtdcSpecificInstrumentField * pSpecificInstrument, CThostFtdcRspInfoField * pRspInfo, int nRequestID, bool bIsLast)
{
	LOG("<OnRspSubMarketData>\n");
	if (pSpecificInstrument)
	{
		LOG("\tInstrumentID = [%s]\n", pSpecificInstrument->InstrumentID);
	}
	if (pRspInfo)
	{
		LOG("\tErrorMsg = [%s]\n", pRspInfo->ErrorMsg);
		LOG("\tErrorID = [%d]\n", pRspInfo->ErrorID);
	}
	LOG("\tnRequestID = [%d]\n", nRequestID);
	LOG("\tbIsLast = [%d]\n", bIsLast);
	LOG("</OnRspSubMarketData>\n");

	if (bIsLast)
	{
#ifdef __WIN_SYS
		SetEvent(m_md_UnSubscribeForQuoteRsp_signal);
#elif defined(__UNIX_SYS)
		sem_post(&m_md_UnSubscribeForQuoteRsp_signal);
#endif // __WIN_SYS
	}
}

void CMdUser::OnRtnDepthMarketData(CThostFtdcDepthMarketDataField * pDepthMarketData)
{
	LOG("<OnRtnDepthMarketData>\n");
	if (pDepthMarketData)
	{
		LOG("\tTradingDay [%s]\n", pDepthMarketData->TradingDay);
		LOG("\tInstrumentID [%s]\n", pDepthMarketData->InstrumentID);
		LOG("\tExchangeID [%s]\n", pDepthMarketData->ExchangeID);
		LOG("\tExchangeInstID [%s]\n", pDepthMarketData->ExchangeInstID);
		LOG("\tUpdateTime [%s]\n", pDepthMarketData->UpdateTime);
		LOG("\tActionDay [%s]\n", pDepthMarketData->ActionDay);
		LOG("\tVolume [%d]\n", pDepthMarketData->Volume);
		LOG("\tUpdateMillisec [%d]\n", pDepthMarketData->UpdateMillisec);
		LOG("\tBidVolume1 [%d]\n", pDepthMarketData->BidVolume1);
		LOG("\tAskVolume1 [%d]\n", pDepthMarketData->AskVolume1);
		LOG("\tBidVolume2 [%d]\n", pDepthMarketData->BidVolume2);
		LOG("\tAskVolume2 [%d]\n", pDepthMarketData->AskVolume2);
		LOG("\tBidVolume3 [%d]\n", pDepthMarketData->BidVolume3);
		LOG("\tAskVolume3 [%d]\n", pDepthMarketData->AskVolume3);
		LOG("\tBidVolume4 [%d]\n", pDepthMarketData->BidVolume4);
		LOG("\tAskVolume4 [%d]\n", pDepthMarketData->AskVolume4);
		LOG("\tBidVolume5 [%d]\n", pDepthMarketData->BidVolume5);
		LOG("\tAskVolume5 [%d]\n", pDepthMarketData->AskVolume5);
		LOG("\tLastPrice [%.8lf]\n", pDepthMarketData->LastPrice);
		LOG("\tPreSettlementPrice [%.8lf]\n", pDepthMarketData->PreSettlementPrice);
		LOG("\tPreClosePrice [%.8lf]\n", pDepthMarketData->PreClosePrice);
		LOG("\tPreOpenInterest [%.8lf]\n", pDepthMarketData->PreOpenInterest);
		LOG("\tOpenPrice [%.8lf]\n", pDepthMarketData->OpenPrice);
		LOG("\tHighestPrice [%.8lf]\n", pDepthMarketData->HighestPrice);
		LOG("\tLowestPrice [%.8lf]\n", pDepthMarketData->LowestPrice);
		LOG("\tTurnover [%.8lf]\n", pDepthMarketData->Turnover);
		LOG("\tOpenInterest [%.8lf]\n", pDepthMarketData->OpenInterest);
		LOG("\tClosePrice [%.8lf]\n", pDepthMarketData->ClosePrice);
		LOG("\tSettlementPrice [%.8lf]\n", pDepthMarketData->SettlementPrice);
		LOG("\tUpperLimitPrice [%.8lf]\n", pDepthMarketData->UpperLimitPrice);
		LOG("\tLowerLimitPrice [%.8lf]\n", pDepthMarketData->LowerLimitPrice);
		LOG("\tPreDelta [%.8lf]\n", pDepthMarketData->PreDelta);
		LOG("\tCurrDelta [%.8lf]\n", pDepthMarketData->CurrDelta);
		LOG("\tBidPrice1 [%.8lf]\n", pDepthMarketData->BidPrice1);
		LOG("\tAskPrice1 [%.8lf]\n", pDepthMarketData->AskPrice1);
		LOG("\tBidPrice2 [%.8lf]\n", pDepthMarketData->BidPrice2);
		LOG("\tAskPrice2 [%.8lf]\n", pDepthMarketData->AskPrice2);
		LOG("\tBidPrice3 [%.8lf]\n", pDepthMarketData->BidPrice3);
		LOG("\tAskPrice3 [%.8lf]\n", pDepthMarketData->AskPrice3);
		LOG("\tBidPrice4 [%.8lf]\n", pDepthMarketData->BidPrice4);
		LOG("\tAskPrice4 [%.8lf]\n", pDepthMarketData->AskPrice4);
		LOG("\tBidPrice5 [%.8lf]\n", pDepthMarketData->BidPrice5);
		LOG("\tAskPrice5 [%.8lf]\n", pDepthMarketData->AskPrice5);
		LOG("\tAveragePrice [%.8lf]\n", pDepthMarketData->AveragePrice);
	}
	LOG("</OnRtnDepthMarketData>\n");
}

void CMdUser::OnRtnForQuoteRsp(CThostFtdcForQuoteRspField * pForQuoteRsp)
{
	LOG("<OnRtnForQuoteRsp>\n");
	if (pForQuoteRsp)
	{
		LOG("\tTradingDay = [%s]\n", pForQuoteRsp->TradingDay);
		LOG("\tInstrumentID = [%s]\n", pForQuoteRsp->InstrumentID);
		LOG("\tForQuoteSysID = [%s]\n", pForQuoteRsp->ForQuoteSysID);
		LOG("\tForQuoteTime = [%s]\n", pForQuoteRsp->ForQuoteTime);
		LOG("\tActionDay = [%s]\n", pForQuoteRsp->ActionDay);
		LOG("\tExchangeID = [%s]\n", pForQuoteRsp->ExchangeID);
	}
	LOG("</OnRtnForQuoteRsp>\n");
}
