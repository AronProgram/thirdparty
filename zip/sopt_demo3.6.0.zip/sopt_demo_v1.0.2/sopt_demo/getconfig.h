#ifndef GETCONFIG_H
#define GETCONFIG_H

#include <string>

using namespace std;

string getConfig(string title, string cfgName);
string getSubstr(const string originstr, int subn, string delims = " ");


#endif
