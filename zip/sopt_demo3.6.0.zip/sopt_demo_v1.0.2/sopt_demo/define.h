#ifndef DEFINE_H
#define DEFINE_H

#include <stdio.h>
#include <map>
#include <string>
#include <iostream>
#include <iomanip>

using namespace std;

#define __WIN_SYS

extern FILE *logfile;
#define LOG(format, ...) fprintf(logfile, format, __VA_ARGS__); printf(format, __VA_ARGS__); fflush(logfile);


class menu
{
public:
	menu();
	~menu();

public:
	map<string, string> menu_main_map;
	map<string, string> menu_trade_map;
	map<string, string> menu_login_map;
	string m_menu_main_chosen;
	string m_menu_login_chosen;
	string m_menu_trade_chosen;
public:
	void menu_main();
	void menu_login();
	void menu_trade();	
};

#endif // DEFINE_H